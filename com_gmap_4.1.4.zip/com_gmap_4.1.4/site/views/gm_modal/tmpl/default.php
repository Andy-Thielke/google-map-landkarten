<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

//-- No direct access
defined('_JEXEC') or die('Restricted access');
$lang = JFactory::getLanguage();
$extension = 'com_gmap';
$base_dir = JPATH_SITE;
$app = JFactory::getApplication();
$app->setTemplate('protostar', null);
$reload = true;
$lang->load($extension, $base_dir, $language_tag, $reload);
function loadJSLanguageKeys($jsFile){
    if (isset($jsFile)){
        $jsFile = JPATH_ROOT. $jsFile;
    }else{
        return false;
    }

    if ($jsContents = file_get_contents($jsFile)){
        $languageKeys = array();
        preg_match_all('/Joomla\.JText\._\(\'(.*?)\'\)\)?/', $jsContents, $languageKeys);
        $languageKeys = $languageKeys[1];

        foreach ($languageKeys as $lkey){
            JText::script($lkey);
        }
    }
}
loadJSLanguageKeys('/plugins/content/plg_content_gmap/gm_map.js');
	$document =& JFactory::getDocument();

JHTML::_('behavior.core', true);
JHtml::_('jquery.framework');
JHtml::_('jquery.ui');
JHtml::_('bootstrap.framework');
	$map=JRequest::getVar('map');
	$document->addScriptDeclaration( $js1 );		
	$document->addScript('https://maps.googleapis.com/maps/api/js?v=3.16&sensor=false&language='.$this->map_parameter['map_language'].'&libraries=weather,drawing,geometry,panoramio');
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/jquery.ui.accordion.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/ajax.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/gm_map.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/markerclusterer_min.js' );
	$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/modal.css');
	require_once 'gmap_mobile_detect.php';
    $detect = new gmap_Mobile_Detect;
    $deviceType = ($detect->isMobile() ? ($detect->isTablet() ?
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_tablet.css')
		: 
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_mobile.css'))
		:
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_pc.css')); 
	$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/jquery.fancybox-1.3.4.css');	
		$js = "var URIBase = '".JURI::root()."';
				var karten = [{'karte':".$map."},];
				document.open();
     			document.write('<html><body><div id=".$map." style=\'width: 100%; height: 100%; \'></div></body></html>');
     			document.close();

				";
		$document->addScript('https://www.google.com/jsapi');
		$document->addScriptDeclaration( $js );		
		$js2 = "google.load('visualization', '1', {packages: ['table','corechart']});
				var URIBase = '".JURI::root()."';";
		$document->addScriptDeclaration( $js2 );	
		
?>
