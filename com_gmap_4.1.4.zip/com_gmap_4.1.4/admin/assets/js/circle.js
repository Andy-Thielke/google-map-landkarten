var circlemarker = new Array();

function showcircle()
{
	setalltextnotactiv();
	controlerRectangle.clearRectangleSelection();
	controlerMarker.clearMarkerSelection();
	controlerLine.clearLineSelection();
	controlerPolygon.clearPolygonSelection();
	google.maps.event.clearListeners(map, 'click');
	showtab(4);
}


function initcircle()
{
	for(var i = 0; i < circle.length; i++)
	{
		circle[i].getInfoWindow = getinfowindow;
		addcircleevent(i);
	}
}

function initcircletabelle() {
	google.maps.event.clearListeners(drawingManager, 'circlecomplete');
  var data = new google.visualization.DataTable();
  data.addColumn('number', 'ID');
  data.addColumn('string', Joomla.JText._('JS_LINE_HEADER_TABLE_CIRCLE_RADIUS'));
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_EDIT'));
  var count = 0;
  for(var i = 0; i < circle.length; i++){
		if(circle[i].status != 'del'){
			data.addRows(1);
			data.setCell(count, 0, i+1);
			data.setCell(count, 1, parseInt(circle[i].radius)+' m');
			data.setCell(count, 2, main.tableButtonShow('circleshow',i)+main.tableButtonDelete('circledel',i)+main.tableButtonInfoWindow('main.InfoWindowOpen',i+', \'circle\'', circle[i].firstinfofenster));
		count++;
		}
		} 
 var table = new google.visualization.Table(document.getElementById('page_circletabelle'));
var view = new google.visualization.DataView(data);
  table.draw(view, {allowHtml: true, showRowNumber: false,cssClassNames: 'cssClassNames'});
table.setSelection([{'row': controlerCircle.returnSelectedCircle()}]);
}


function circlenew()
{
	showsubtab (0, 'circle');
	controlerCircle.clearCircleSelection();
	google.maps.event.clearListeners(drawingManager, 'circlecomplete');
	drawingManager.setDrawingMode(google.maps.drawing.OverlayType.CIRCLE);
	drawingManager.setOptions({circleOptions:{
		fillColor: '',
		fillOpacity: '',
		strokeWeight: 1,
		clickable: false,
		zIndex: 1,
		editable: true
	}})
google.maps.event.addListener(drawingManager, 'circlecomplete', function(drawcircle) {
	drawingManager.setDrawingMode(null);
	var newcid = circle.length;
	circle[newcid]=(new google.maps.Circle(
	{
		map : map,
		circle_id : newcid,
		center: drawcircle.getCenter(), 
		gmselected : 'true', 
		status : 'isedit',
		text:'', 
		fillColor : '', 
		fillOpacity : '',
		strokeColor: '',
		strokeOpacity: '', 
		strokeWeight : 1, 
		firstinfofenster:'false',
		positinfowindowlat:'',
		positinfowindowlng:'',
		positinfowindow: 'false',
		radius : drawcircle.getRadius(), 
		circle_new : 'yes', 
		editable: true
	}));
	$('jform_circle_marker1').value = circle[newcid].getCenter();
	$('jform_circle_radius').value = circle[newcid].radius;
	var cid = circle.length-1;
	drawcircle.setMap(null);
	circle[cid].getInfoWindow = getinfowindow;
	setcircleoption();
	addcircleevent(cid);
});
}

function addcircleevent(cid)
{
	google.maps.event.addListener(circle[cid], 'click', function(event)
	{
		showcircle();
		controlerCircle.clearCircleSelection();
		circle[cid].gmselected = 'true';
		getcircleoption(cid);
		circle[cid].setEditable(true);
		circle[cid].getInfoWindow(event, 'Circle');
		initcircletabelle();
		
	});
	google.maps.event.addListener(circle[cid], 'center_changed', function()
	{
		$('jform_circle_marker1').value = circle[cid].getCenter();
		circle[cid].status = 'isedit';
	});
	google.maps.event.addListener(circle[cid], 'radius_changed', function()
	{
		$('jform_circle_radius').value = circle[cid].radius;
		circle[cid].status = 'isedit';
	});
}

function setcircleradius()
{
		for(var i = 0; i < circle.length; i++){
			if (circle[i].gmselected == 'true'){
          circle[i].setRadius($('jform_circle_radius').value);
		  setcircleedit(i);
		}
       }
}

function setcircleedit(cid){
	if(circle[cid].oldfillColor != circle[cid].fillColor || circle[cid].oldfillOpacity != circle[cid].fillOpacity || circle[cid].oldstrokeColor != circle[cid].strokeColor || circle[cid].oldstrokeOpacity != circle[cid].strokeOpacity || circle[cid].oldstrokeWeight != circle[cid].strokeWeight || circle[cid].circle_new == 'yes' || circle[cid].oldradius != circle[cid].radius)
	{
		circle[cid].status = 'isedit';
	}
}

var controlerCircle ={
	clearCircleSelection: function(option){
		for(var i = 0; i < circle.length; i++){
		  circle[i].setEditable(false);
		  circle[i].gmselected = 'false';
		  infowindow.open(null);
		}
	},	
	returnSelectedCircle: function(option){
		for(var i = 0; i < circle.length; i++){
          if (circle[i].gmselected == 'true'){
			 return i; 
		  }};
		  return false;
	},	
	setCircleText: function(option){
		var cid = this.returnSelectedCircle();
		if (cid === false) return;
		circle[cid].status = 'isedit';
		circle[cid].text = document.getElementById('jform_circle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
		circle[cid].text = returnFullImagePath(circle[cid].text);
		infowindow.setContent(circle[cid].text);
		infowindow.open(map);
	},	
	deleteCircleText: function(option){
		var cid =this.returnSelectedCircle();
		if (cid === false) return;
		circle[cid].status = 'isedit';
		circle[cid].text = '';
		document.getElementById('jform_circle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML ='';
		infowindow.open(null);
	},
	setInfoWindowPosition: function(){
		var cid = this.returnSelectedCircle();
		if (cid === false) return;
		circle[cid].positinfowindow = circle[cid].temppositinfowindow;
		circle[cid].positinfowindowlat = infowindow.position.lat();
		circle[cid].positinfowindowlng = infowindow.position.lng();
		circle[cid].status = 'isedit';
		circle[cid].getInfoWindow('default', 'Circle');
		},
	deleteCirclePosition: function(option){
		var cid = this.returnSelectedCircle();
		if (cid === false) return;
		circle[cid].positinfowindow = 'false';
		circle[cid].positinfowindowlat = '';
		circle[cid].positinfowindowlng = '';
		circle[cid].status = 'isedit';
		circle[cid].getInfoWindow('default', 'Circle');
	},
	setInfoWindowOpen: function(option){
		var cid = this.returnSelectedCircle();
		if (cid === false) return;
		main.InfoWindowOpen(cid,'circle', option);
		},
}

function setcircleoption()
{
	var farbelinie = $('jform_circle_farbe_linie').value;
	var farbefuellung = $('jform_circle_farbe_fuellung').value;
	var fuellungtrans = $('jform_circle_transparent_fuellung').value;
	if(farbefuellung == '')
	{
		fuellungtrans = 0.0;
	}
	for(var i = 0; i < circle.length; i++){
		if (circle[i].gmselected == 'true'){
			circle[i].setOptions(
			{
				strokeColor : farbelinie, 
				strokeWeight : $('jform_circle_linie_breite').value, 
				strokeOpacity : $('jform_circle_transparent_linie').value, 
				fillColor : farbefuellung, fillOpacity : fuellungtrans, 
				radius : eval($('jform_circle_radius').value),
			});
		}
	};
	//setcircleedit(cid);
}

function getcircleoption(cid)
{
	$('jform_circle_marker1').value = circle[cid].getCenter();
	$('jform_circle_radius').value = circle[cid].radius;
	$('jform_circle_farbe_linie').value = circle[cid].strokeColor;
	setSelectedValue('jform_circle_linie_breite', circle[cid].strokeWeight);
	setSelectedValue('jform_circle_transparent_linie', circle[cid].strokeOpacity);
	$('jform_circle_farbe_fuellung').value = circle[cid].fillColor;
	setSelectedValue('jform_circle_transparent_fuellung', circle[cid].fillOpacity);
	document.getElementById('jform_circle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML =  circle[cid].text;
	radionSetCheckedValue('jform_circle_infowindow_open',circle[cid].firstinfofenster);

}

function circleshow(cid){
	controlerCircle.clearCircleSelection();
	map.setCenter(circle[cid].getCenter());
	circle[cid].gmselected = 'true';
	getcircleoption(cid);
	circle[cid].setEditable(true);
	$('jform_circle_marker1').value = circle[cid].getCenter();
	$('jform_circle_radius').value = circle[cid].radius;
}

function circledel(cid){
			circle[cid].setMap(null);
			removedata('remove_circle', circle[cid].circle_id);
			circle[cid].status = 'del';
		cleartxt.circletxt();
	initcircletabelle()
}


function selectedcircledelete()
{
	for(var i = 0; i < circle.length; i++)
	{
		if(circle[i].gmselected == 'true')
		{
			circle[i].setMap(null);
			removedata('remove_circle', circle[i].circle_id);
			circle[i].status = 'del';
			$('jform_circle_marker1').value = '';
			$('jform_circle_radius').value = '';
		}
	}

	initcircletabelle();
}

function saveallcircle(){
	var counter1 = 0;
	var counter2 = 0;
	controlerCircle.clearCircleSelection();
	for(var i = 0; i < circle.length; i++){
		if(circle[i].status != 'del' && circle[i].status != 'standard'){
			counter1 += 1;
			}
		}
	if (counter1 != 0){	
		for(var i = 0; i < circle.length; i++){
			if(circle[i].status != 'del' && circle[i].status != 'standard'){
				counter2 += 1;
				if (counter1 > counter2){
					circle[i].circlemarkerlat = circle[i].getCenter().lat();
					circle[i].circlemarkerlng = circle[i].getCenter().lng();
					savecircle(i);
				}else if(counter1 == counter2){
					var last ='true';
					circle[i].circlemarkerlat = circle[i].getCenter().lat();
					circle[i].circlemarkerlng = circle[i].getCenter().lng();
					savecircle(i, last);
				}
			}
			circle[i].setMap(null)
		}
	}else{
	 main.SaveProgress(14);	
	}
	$('jform_circle_marker1').value = '';
	$('jform_circle_radius').value = '';
}
