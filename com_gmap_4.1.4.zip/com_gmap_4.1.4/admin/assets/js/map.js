var mapsetup='on';
function get_default_option(){
	$('jform_map_center_lat').value = $('default_lat').value;
	$('jform_map_center_lng').value = $('default_lng').value;
	$('jform_map_zoom').value = $('default_zoom').value;
}
function init_map_option(){
	var option = {
			zoom: eval($('jform_map_zoom').value),
			mapTypeControl: false,
			center: new google.maps.LatLng($('jform_map_center_lat').value,$('jform_map_center_lng').value),
						};
	jQuery("#gmap-center-lat").html("Latitude: " + $('jform_map_center_lat').value);
	jQuery("#gmap-center-lng").html("Longitude: " + $('jform_map_center_lng').value);
	jQuery("#gmap-zoom-level").html($('jform_map_zoom').value);
		return option;
						
}


var setmapoption ={
	map_satellite_45			:function(option){map.setTilt(eval(option));},
	satellite_view_45_heading	:function(option){map.setHeading(eval(option));},
	map_scrollwheel				:function(option){map.setOptions({scrollwheel:option});},
	map_DoubleClickZoom			:function(option){map.setOptions({disableDoubleClickZoom:option});},
	map_overview_map			:function(option){map.setOptions({overviewMapControl:option});},
	map_overview_map_open		:function(option){map.setOptions({overviewMapControlOptions:{opened : option},});},
	map_draggable				:function(option){map.setOptions({draggable:option});},
	map_panControl				:function(option){map.setOptions({panControl:option});},
	map_zoomControl				:function(option){map.setOptions({zoomControl:option});},
	map_ZoomControlStyle		:function(option){map.setOptions({zoomControlOptions:{style : eval(option)}});},
	map_scaleControl			:function(option){map.setOptions({scaleControl:option});},
	streetViewControl			:function(option){map.setOptions({streetViewControl:option});},
	map_minzoom					:function(option){map.setOptions({minZoom:eval(option)});},
	map_maxzoom					:function(option){map.setOptions({maxZoom:eval(option)});},
	map_zoom					:function(option){map.setOptions({zoom:eval(option)});},
	map_center_lat				:function(option){map.setOptions({
									center :new google.maps.LatLng(option,eval($('jform_map_center_lng').value))});},
	map_center_lng				:function(option){map.setOptions({
									center :new google.maps.LatLng(eval($('jform_map_center_lat').value),option)});},
	map_weather_temperature_unit:function(option){weather_layer.setOptions({
									temperatureUnits: google.maps.weather.TemperatureUnit[option]})},
	map_weather_windspeed_unit	:function(option){weather_layer.setOptions({
									windSpeedUnits: google.maps.weather.WindSpeedUnit[option]})},
	language					:function(option){
									var check = option == '0' ?
										[
										$('jform_custom_map_language').style.visibility='visible',
										$('jform_custom_map_language').focus(), 
										]:[
										$('jform_custom_map_language').style.visibility='hidden',
										$('jform_custom_map_language').value=''
										]
								},
	map_setup_button			:function(option){$('setup-button').setStyle('display', option);},
	map_typ_control_button		:function(option){$('accordion_toggler_1').setStyle('display', option);},
	map_layer_button			:function(option){$('accordion_toggler_2').setStyle('display', option);},
	map_panoramio_button		:function(option){$('accordion_toggler_3').setStyle('display', option);},
	map_streetviewcontrol		:function(option){map.setOptions({streetViewControl:option});},

}

////////////action vom steuerbutton////
var setmaplayer ={
	maptyp		: function(button){
					var listitem = new Array();
					listitem =	$$('#button_wrapper_1 li.list_item_on');	
					listitem.removeClass('list_item_on').addClass('list_item_off'); 
					gm_element('map_view_item_'+button).removeClass('list_item_off').addClass('list_item_on');
					map.setOptions({mapTypeId:button});
					if (button == 'satellite' || button == 'hybrid'){
						jQuery( "#satellite_view_45" ).slideDown( "slow");
					}else{
						jQuery( "#satellite_view_45" ).slideUp( "slow");
					}
				  },
	map_bike_layer: function(option){
						if(option == 'null'){
							bike_layer.setMap(null);
							gm_element('map_layer_bike').removeClass('list_item_on').addClass('list_item_off');
							return;
						}
						if(option == 'map'){
							bike_layer.setMap(map);
							gm_element('map_layer_bike').removeClass('list_item_off').addClass('list_item_on');
							return;
						}
			  		var check = bike_layer.getMap() == null ?
					 [
					 bike_layer.setMap(map),
					 gm_element('map_layer_bike').removeClass('list_item_off').addClass('list_item_on'),
					 ]:[
					 bike_layer.setMap(null),
					 gm_element('map_layer_bike').removeClass('list_item_on').addClass('list_item_off'),
					 ]},
	map_traffic_layer: function(option){
						if(option == 'null'){
							traffic_layer.setMap(null);
							gm_element('map_layer_traffic').removeClass('list_item_on').addClass('list_item_off');
							return;
						}
						if(option == 'map'){
							traffic_layer.setMap(map);
							gm_element('map_layer_traffic').removeClass('list_item_off').addClass('list_item_on');
							return;
						}
			  		var check = traffic_layer.getMap() == null ?
					 [
					 traffic_layer.setMap(map),
					 gm_element('map_layer_traffic').removeClass('list_item_off').addClass('list_item_on'),
					 ]:[
					 traffic_layer.setMap(null),
					 gm_element('map_layer_traffic').removeClass('list_item_on').addClass('list_item_off'),
					 ]},
	map_transit_layer: function(option){
						if(option == 'null'){
							transit_layer.setMap(null);
							gm_element('map_layer_transit').removeClass('list_item_on').addClass('list_item_off');
							return;
						}
						if(option == 'map'){
							transit_layer.setMap(map);
							gm_element('map_layer_transit').removeClass('list_item_off').addClass('list_item_on');
							return;
						}
			  		var check = transit_layer.getMap() == null ?
					 [
					 transit_layer.setMap(map),
					 gm_element('map_layer_transit').removeClass('list_item_off').addClass('list_item_on'),
					 ]:[
					 transit_layer.setMap(null),
					 gm_element('map_layer_transit').removeClass('list_item_on').addClass('list_item_off'),
					 ]},
	map_weather_layer: function(option){
						if(option == 'null'){
							weather_layer.setMap(null);
							gm_element('map_layer_weather').removeClass('list_item_on').addClass('list_item_off');
							return;
						}
						if(option == 'map'){
							weather_layer.setMap(map);
							gm_element('map_layer_weather').removeClass('list_item_off').addClass('list_item_on');
							return;
						}
			  		var check = weather_layer.getMap() == null ?
					 [
					 weather_layer.setMap(map),
					 gm_element('map_layer_weather').removeClass('list_item_off').addClass('list_item_on'),
					 ]:[
					 weather_layer.setMap(null),
					 gm_element('map_layer_weather').removeClass('list_item_on').addClass('list_item_off'),
					 ]},
	map_streetview_layer: function(){
					 streetview_layer.setVisible(true)
						},
	map_panoramio_layer: function(option){
						if(option == 'null'){
							panoramio_layer.setMap(null);
							gm_element('map_layer_panoramio').removeClass('list_item_on').addClass('list_item_off');
							return;
						}
						if(option == 'map'){
							panoramio_layer.setMap(map);
							gm_element('map_layer_panoramio').removeClass('list_item_off').addClass('list_item_on');
							return;
						}
			  		var check = panoramio_layer.getMap() == null ?
					 [
					 panoramio_layer.setMap(map),
					 gm_element('map_layer_panoramio').removeClass('list_item_off').addClass('list_item_on'),
					 ]:[
					 panoramio_layer.setMap(null),
					 gm_element('map_layer_panoramio').removeClass('list_item_on').addClass('list_item_off'),
					 ]}
}

//////////Refresh der Karte auf Backendwerte////////////
function setmapcenter () {
	var mapcenter = new google.maps.LatLng($('jform_map_center_lat').value,$('jform_map_center_lng').value);
	map.setOptions({
		center: mapcenter,
		minZoom:parseInt($('jform_map_minzoom').value),
		maxZoom:parseInt($('jform_map_maxzoom').value),
		zoom: parseInt($('jform_map_zoom').value)
		})
}
//////////Übernahme der Kartenwerte ins Backend///////////
function getmapcenter () {
	var mapcenter =  map.getCenter();
	$('jform_map_center_lat').value =mapcenter.lat();
	$('jform_map_center_lng').value =mapcenter.lng();
	
}
////////////Übernahme der Zoom Kartenwerte ins Backend/////////
var setzoom ={
	map_zoom			:function(option){$('jform_map_zoom').value = map.getZoom();},
	map_minzoom			:function(option){$('jform_map_minzoom').value = map.getZoom();
											map.setOptions({minZoom: map.getZoom()});},
	map_maxzoom			:function(option){$('jform_map_maxzoom').value = map.getZoom();
											map.setOptions({maxZoom: map.getZoom()});},
	reset_zoom			:function(option){map.setOptions({minZoom: null,maxZoom: null,})
											$('jform_map_minzoom').value = '';
											$('jform_map_maxzoom').value = '';},
}
///////////Steuerbutton einbinden/////////////
function setmapbutton(){
	var mycustom = new Element('div', {
		'id' : 'setup_map_button',
		'class' : 'setup_map_button'
	});
	mycustom.innerHTML =maplang['map_button_html'];
	map.controls[google.maps.ControlPosition.TOP_RIGHT].push(mycustom);
	google.maps.event.clearListeners(map, 'tilesloaded');
		loadaccordion();			
}
////////////action Steuerbutton//////////
function togglemapsetupview () {
		var check = (mapsetup == 'on') ?
			mapsetupviewoff() :
			mapsetupviewon();
}

function mapsetupviewon (){
	$('setup_button_box').show();
		mapsetup = 'on'	;
}
function mapsetupviewoff (){
		$('setup_button_box').hide();
			mapsetup = 'off'	;
}


//////////////////////////////streetview///////////////////////////////////////
var map_streetview ={
	loadsaveddata		:function(option){
						if($('jform_street_view_center_lat').value != ''){
							var mapcenter = new google.maps.LatLng($('jform_street_view_center_lat').value,
																	$('jform_street_view_center_lng').value);
								streetview_layer.setPosition(mapcenter);
								streetview_layer.setPov({
													heading:parseFloat($('jform_street_view_heading').value),
													zoom:	parseInt($('jform_street_view_zoom').value),
													pitch:	parseFloat($('jform_street_view_pitch').value)
													});
									$('jform_street_view_activ').show();
									$('jform_street_view_activ-lbl').show();
									$('map_layer_streetview').removeClass('button_view_off').addClass('list_item_off');
						}else{
									$('jform_street_view_activ').hide();
									$('jform_street_view_activ-lbl').hide();
									$('map_layer_streetview').removeClass('list_item_off').addClass('button_view_off');
						}
					},
	getfrommap		:function(option){
							if 	(center = streetview_layer.getPosition()){
								if (center.lat() && center.lng() != '') {
									$('jform_street_view_center_lat').value = center.lat();
									$('jform_street_view_center_lng').value = center.lng();
									$('jform_street_view_heading').value = streetview_layer.getPov().heading;
									$('jform_street_view_pitch').value = streetview_layer.getPov().pitch;
									$('jform_street_view_zoom').value = streetview_layer.getPov().zoom;
									$('jform_street_view_activ').show();
									$('jform_street_view_activ-lbl').show();
									$('map_layer_streetview').removeClass('button_view_off').addClass('list_item_off');
								}
							}
					},
	delete_view		:function(option){
							$('jform_street_view_center_lat').value = '';
							$('jform_street_view_center_lng').value = '';
							$('jform_street_view_heading').value = '';
							$('jform_street_view_pitch').value = '';
							$('jform_street_view_zoom').value = '';
							streetview_layer.setOptions({visible:false});
							$('jform_street_view_activ').hide();
							$('jform_street_view_activ-lbl').hide();
							$('map_layer_streetview').removeClass('list_item_off').addClass('button_view_off');
					},
	refresh_view	:function(option){
						if($('jform_street_view_center_lat').value != ''){
							var mapcenter = new google.maps.LatLng($('jform_street_view_center_lat').value,
																	$('jform_street_view_center_lng').value);
								streetview_layer.setPosition(mapcenter);
								streetview_layer.setPov({
													heading:parseFloat($('jform_street_view_heading').value),
													zoom:	parseInt($('jform_street_view_zoom').value),
													pitch:	parseFloat($('jform_street_view_pitch').value)
													});
								streetview_layer.setOptions({visible:true});
						}
		},
}

////////////////panoramio//////////////////////
var map_panoramio ={
	refresh_view				:function(option){
										panoramio_layer.setTag($('jform_panoramio_tag').value);
										panoramio_layer.setUserId($('jform_panoramio_userid').value);
										panoramio_layer.setMap(map);
								},
}

function loadaccordion() {
	// Anpassung IE6
	if(window.ie6) var heightValue='100%';
	else var heightValue='';
	
	// Selektoren der Container für Schalter und Inhalt
	var togglerName='dt.accordion_toggler_';
	var contentName='dd.accordion_content_';
	
	// Selektoren setzen
	var counter=1;	
	var toggler=$$(togglerName+counter);
	var content=$$(contentName+counter);
	while(toggler.length>0)
	{
		// Accordion anwenden
		new Fx.Accordion(toggler, content, {
			opacity: false,
			display: -1,
			alwaysHide: true,
			onComplete: function() {
				var element=$(this.elements[this.previous]);
				if(element && element.offsetHeight>0) element.setStyle('height', heightValue);			
			},
			onActive: function(toggler, content) {
				toggler.addClass('open');
			},
			onBackground: function(toggler, content) {
				toggler.removeClass('open');
			}
		});
		
		// Selektoren für nächstes Level setzen
		counter++;
		toggler=document.getElementsByClassName(togglerName+counter);
		content=document.getElementsByClassName(contentName+counter);
	}
	google.maps.event.clearListeners(map, 'tilesloaded');

}