var breite = 'min';
var hoehe = 'auto';
var textid;

function showtext()
{
	controlerRectangle.clearRectangleSelection();
	controlerCircle.clearCircleSelection();
	controlerMarker.clearMarkerSelection();
	controlerLine.clearLineSelection();
	controlerPolygon.clearPolygonSelection();
	google.maps.event.clearListeners(map, 'click');
	showtab(7);
}


function inittext(){
	for(var i = 0; i < textmarker.length; i++)
	{
		text[i] = new ToolTip(breite, hoehe, map, textmarker[i].position, textmarker[i].text, i);
		addtextevent(i);
	}
}

function inittexttabelle(){
	var myTable = new HtmlTable({
		properties :{
			id : 'text-tabelle', border : 0, class: 'table table-striped'},
			headers : ['Nr.', 'Inhalt', 'Bearbeitung']
		});
	if($('text-tabelle')){
		myTable.replaces($('text-tabelle'));
	}
	else{
		myTable.inject($('page_texttabelle'));
	}
var k = 0;
	for(var i = 0; i < textmarker.length; i++){
		if(textmarker[i].status != 'del'){
			var text = returnFullImagePath(textmarker[i].text);
			//var text = textmarker[i].text.replace(/src=\"/g, 'src="' + URIBase);
			myTable.push([
				'Nr. ' + (i + 1),
				text,
				'<a href="#" onclick="textshow(' + i + ');"><img class="assume" title="HTML Box auf der Karte zeigen" src="components/com_gmap/assets/images/eye.png" width="16" height="16" /></a><a href="#" onclick="textdel(' + i + ');"><img class="assume" title="HTML Box löschen" src="components/com_gmap/assets/images/reset.png" width="16" height="16" /></a>'
			 ],{'class': 'row'+k+''});
		}
		k = 1 - k;
	}
}

function addtextevent(tid)
{
	google.maps.event.addListener(textmarker[tid], 'dragstart', function(event)
	{
		textmarker[tid].status = 'isedit';
		showtext();
	}

	);
	google.maps.event.addListener(textmarker[tid], 'dragend', function(event)
	{
		settextactiv(tid);
		textmarker[tid].lat = textmarker[tid].position.lat();
		textmarker[tid].lng = textmarker[tid].position.lng();
		$('jform_text_lat').value = (textmarker[tid].lat);
		$('jform_text_lng').value = (textmarker[tid].lng);
	}

	);
	google.maps.event.addListener(textmarker[tid], 'drag', function(event)
	{
		text[tid].setMap(null);
		text[tid] = new ToolTip(breite, hoehe, map, event.latLng, textmarker[tid].text, tid);
	}

	);
}

function textnew()
{
	setalltextnotactiv();
	showsubtab (0, 'htmlbox');
	$('jform_text_lat').value = '';
	$('jform_text_lng').value = '';
	document.getElementById('jform_text_box_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = 'Neue HTML Box';

	google.maps.event.addListener(map, 'click', function(event)
	{
		var newrid = textmarker.length;
		$('activtext').value = newrid;
		textmarker[newrid] = new google.maps.Marker(
		{
			id : '', lat : '', lng : '', text : 'Neue HTML Box', title : '#' + newrid, map : map, text_new : 'yes', status : 'isedit', textselected : 'true', visible : true, draggable : true, icon : mysystemicon('element_activ_nosave.png', 15, 26, 7, 7),
		}

		);
		addtextevent(newrid);
		if($('jform_text_lat').value == '' || $('jform_text_lng').value == '')
		{
			textmarker[newrid].setOptions(
			{
				map : map, 
				position : event.latLng,
			}

			);
			text[newrid] = new ToolTip(breite, hoehe, map, event.latLng, textmarker[newrid].text, newrid);
			textmarker[newrid].lat = textmarker[newrid].position.lat();
			textmarker[newrid].lng = textmarker[newrid].position.lng();
			$('jform_text_lat').value = textmarker[newrid].lat;
			$('jform_text_lng').value = textmarker[newrid].lng;
			google.maps.event.clearListeners(map, 'click');
		}
		else
		{
			google.maps.event.clearListeners(map, 'click');
		}
	}

	);
	inittexttabelle();
}

function setalltextnotactiv()
{
	var tid = $('activtext').value;
	if(tid != '')
	{
		textsetnewcontent(tid);
		cleartxt.texttxt();
	};

	$('activtext').value = '';
	for(var i = 0; i < textmarker.length; i++)
	{
		textmarker[i].textselected = 'false';
		settextedit();
		if(textmarker[i].status == 'standard')
		{
			textmarker[i].setOptions(
			{
				draggable : false, visible : false,
			}

			);
		}

		if(textmarker[i].status == 'isedit')
		{
			textmarker[i].setOptions(
			{
				icon : mysystemicon('element_passiv_no_save.png', 15, 15, 7, 7), draggable : false, visible : true,
			}

			);
		}
	}
}

function settextactiv(tid)
{
	var lasttid = $('activtext').value;
	if(lasttid == '')
	{
		showtext();
	}

	if(lasttid != '')
	{
		textsetnewcontent(lasttid);
		showtext();
	}

	setalltextnotactiv();
	$('activtext').value = tid;
	if(textmarker[tid].status == 'isedit')
	{
		textmarker[tid].setOptions(
		{
			icon : mysystemicon('element_activ_nosave.png', 15, 15, 7, 7),
		}

		);
	}

	textmarker[tid].setOptions(
	{
		visible : true, draggable : true,
	}

	);
	textmarker[tid].textselected = 'true';
	textgetnewcontent(tid);
}

function settextedit()
{
	for(var i = 0; i < textmarker.length; i++)
	{
		if(textmarker[i].oldtext != textmarker[i].text || textmarker[i].text_new == 'yes')
		{
			if(textmarker[i].status != 'del')
			{
				textmarker[i].status = 'isedit';
			}
		}
	}
}

function textgetsavecontent(tid)
{
	$('jform_text_lat').value = (textmarker[tid].oldlat);
	$('jform_text_lng').value = (textmarker[tid].oldlng);
	document.getElementById('jform_text_box_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = textmarker[tid].oldtext;
}

function textgetnewcontent(tid)
{
	$('jform_text_lat').value = (textmarker[tid].lat);
	$('jform_text_lng').value = (textmarker[tid].lng);
	document.getElementById('jform_text_box_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = textmarker[tid].text;
}

function textsetnewcontent(tid)
{
	textmarker[tid].lat = $('jform_text_lat').value;
	textmarker[tid].lng = $('jform_text_lng').value;
	textmarker[tid].text = document.getElementById('jform_text_box_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
	textmarker[tid].text = returnFullImagePath(textmarker[tid].text);
	text[tid].setMap(null);
	text[tid] = new ToolTip(breite, hoehe, map, textmarker[tid].getPosition(), textmarker[tid].text, tid);
}

function textiseditnosave()
{
	for(var i = 0; i < textmarker.length; i++)
	{
		if(textmarker[i].textselected == 'true')
		{
			textmarker[i].status = 'isedit';
			textsetnewcontent(i);
			settextactiv(i);
		}
	}
}

function textshow(tid)
{
	$('activtext').value = tid;
	map.setCenter(textmarker[tid].getPosition());
	for(var i = 0; i < textmarker.length; i++)
	{
		textmarker[i].setOptions(
		{
			draggable : false, visible : false,
		}

		);
		if(textmarker[i].status == 'isedit')
		{
			textmarker[i].setOptions(
			{
				icon : mysystemicon('element_passiv_no_save.png', 15, 15, 7, 7), draggable : false, visible : true,
			}

			);
			textmarker[i].textselected = 'false';
		}

		if(textmarker[tid].status == 'isedit')
		{
			textmarker[tid].setOptions(
			{
				icon : mysystemicon('element_activ_nosave.png', 15, 15, 7, 7),
			}

			);
		}
	}

	textmarker[tid].setOptions(
	{
		visible : true, draggable : true,
	}

	);
	textmarker[tid].textselected = 'true';
	textgetnewcontent(tid);
}
function textdel (tid) {
			text[tid].setMap(null);
			textmarker[tid].setMap(null);
			$('activtext').value = '';
			removedata('remove_htmlbox', textmarker[tid].id);
			textmarker[tid].status = 'del';
			textmarker[tid].textselected = 'false';
	cleartxt.texttxt();
	inittexttabelle();
}
function selectedtextdelete()
{
	for(var i = 0; i < textmarker.length; i++)
	{
		if(textmarker[i].textselected == 'true')
		{
			text[i].setMap(null);
			textmarker[i].setMap(null);
			$('activtext').value = '';
			removedata('remove_htmlbox', textmarker[i].id);
			textmarker[i].status = 'del';
			textmarker[i].textselected = 'false';
		}
	}

	cleartxt.texttxt();
}

function resettext()
{
	for(var i = 0; i < textmarker.length; i++)
	{
		if(textmarker[i].textselected == 'true' && textmarker[i].text_new == 'no' && textmarker[i].status != 'del')
		{
			var posit1 = new google.maps.LatLng(textmarker[i].oldlat, textmarker[i].oldlng);
			textmarker[i].setOptions(
			{
				position : posit1, icon : mysystemicon('element_activ.png', 15, 15, 7, 7),
			}

			);
			textgetsavecontent(i);
			text[i].setMap(null);
			text[i] = new ToolTip(breite, hoehe, map, posit1, textmarker[i].oldtext, i);
			textmarker[i].status = 'standard';
		}
	}
}

function savealltext()
{
	var tid = $('activtext').value;
	if(tid != '')
	{
		textsetnewcontent(tid);
	};
	var counter1 = 0;
	var counter2 = 0;
	for(var i = 0; i < textmarker.length; i++){
		if(textmarker[i].status != 'del' && textmarker[i].status != 'standard'){
			counter1 += 1;
			}
		}
	if (counter1 != 0){	
		for(var i = 0; i < textmarker.length; i++){
			if(textmarker[i].status != 'del' && textmarker[i].status != 'standard'){
				counter2 += 1;
				if (counter1 > counter2){
					savetext(i);
				}else if(counter1 == counter2){
					var last ='true';
					savetext(i, last);
				}
			}
			textmarker[i].setMap(null);
			text[i].setMap(null);
			textmarker[i].textselected == 'false';
		}
	}else{
	 main.SaveProgress(16);	
	}
	$('activtext').value = '';
	cleartxt.texttxt();
	
}
ToolTip.prototype = new google.maps.OverlayView();
function ToolTip(breite, hoehe, map, latlng, text, tid)
{
	//text = text.replace(/src=\"/g, 'src="' + URIBase);
	this.versatz_x_ = 0;
	this.versatz_y_ = 0;
	this.latlng_ = latlng;
	this.map_ = map;
	this.breite_ = breite;
	this.hoehe_ = hoehe;
	this.html_ = text;
	this.textid = tid;
	this.div_ = null;
	this.setMap(map);
}

ToolTip.prototype.onAdd = function()
{
	var div = document.createElement('DIV');
	div.innerHTML = this.html_;
	div.setAttribute("id", "text");
	div.setAttribute("onclick", "settextactiv(" + this.textid + ")");
	div.style.position = "absolute";
	this.div_ = div;
	var panes = this.getPanes();
	panes.overlayImage.appendChild(div);
};

ToolTip.prototype.draw = function()
{
	var overlayProjection = this.getProjection();
	var pixPosition = this.getProjection().fromLatLngToDivPixel(this.latlng_);
	if(!pixPosition)
		return;

	var div = this.div_;
	div.style.left = (pixPosition.x + this.versatz_x_) + "px";
	div.style.top = (pixPosition.y + this.versatz_y_) + "px";
	div.style.width = this.breite_;
	div.style.height = this.hoehe_ + 'px';
};

ToolTip.prototype.onRemove = function()
{
	this.div_.parentNode.removeChild(this.div_);
	this.div_ = null;
};