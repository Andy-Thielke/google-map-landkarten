// JavaScript Document

function showline()
{
	setalltextnotactiv();
	controlerRectangle.clearRectangleSelection();
	controlerCircle.clearCircleSelection();
	controlerMarker.clearMarkerSelection();
	controlerPolygon.clearPolygonSelection();
	showtab(5);
	google.maps.event.clearListeners(map, 'click');
}


function initline()
{
	for(var i = 0; i < line.length; i++)
	{
		//add new Methods
		line[i].getLength = getlinelength;
		line[i].setChart = setlinechart;
		line[i].getInfoWindow = getinfowindow;
		line[i].setFormOption = setlineformoption;
		//ende
		addlineevent(i);
		for(var p = 0; p < linemarker[i].length; p++)
		{
			addlinemarkerevent(i, p);
		}
	}

	initlinetabelle();
	controlerLine.clearLineSelection();
}

function initlinetabelle() {
  var data = new google.visualization.DataTable();
  data.addColumn('number', 'ID');
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_TITLE'));
  data.addColumn('string', Joomla.JText._('JS_LINE_HEADER_TABLE_LINE_LENGTH'));
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_EDIT'));
  var count = 0;
  for(var i = 0; i < line.length; i++){
		if(line[i].status != 'del'){
			data.addRows(1);
			data.setCell(count, 0, i+1);
			data.setCell(count, 1, line[i].linetitel);
			data.setCell(count, 2, line[i].getLength()+' km');
			data.setCell(count, 3, main.tableButtonShow('lineshow',i)+main.tableButtonDelete('linedel',i)+main.tableButtonInfoWindow('main.InfoWindowOpen',i+', \'line\'', line[i].firstinfofenster));
		count++;
		}
		} 
 var table = new google.visualization.Table(document.getElementById('page_linetabelle'));
var view = new google.visualization.DataView(data);
  table.draw(view, {allowHtml: true, showRowNumber: false,cssClassNames: 'cssClassNames'});
 table.setSelection([{'row': controlerLine.returnSelectedLine()}]);
}


function addmapevent(lid)
{
	google.maps.event.clearListeners(map, 'click');
	google.maps.event.addListener(map, 'click', function(event)
	{
		var newpoint = event.latLng;
		var path = line[lid].getPath();
		path.push(newpoint);
		line[lid].setPath(path);
		line[lid].getLength();
	});
	google.maps.event.clearListeners(map, 'rightclick');
	google.maps.event.addListener(map, 'rightclick', function(event)
	{
		google.maps.event.clearListeners(map, 'click');
		map.setOptions({draggableCursor:''});
		line[lid].setEditable(false);
		controlerLine.clearLineSelection();
		$('line_length').innerHTML = '';
		for(var p = 0; p < linemarker[lid].length; p++){
			linemarker[lid][p].setVisible(false);
		}
	});
}

function addlineevent(lid)
{
	
	google.maps.event.addListener(line[lid], 'click', function(event)
	{
		showline();
		controlerLine.clearLineSelection();
		map.setOptions({draggableCursor:'crosshair'});
		line[lid].gmselected = 'true';
		addmapevent(lid);
		for(var p = 0; p < linemarker[lid].length; p++){
			linemarker[lid][p].setVisible(true);
		}
		line[lid].setEditable(true);
		line[lid].setChart();
		line[lid].getInfoWindow(event, 'Line');
		line[lid].setFormOption();
		initlinetabelle();
		line[lid].getLength();
	});

	google.maps.event.addListener(line[lid].getPath(), 'insert_at', function(index) {
		line[lid].status = 'isedit';
		var point= line[lid].getPath().getArray();
		linemarker[lid][linemarker[lid].length] = new google.maps.Marker({
			position : point[index],
			title : '#' + index, 
			map : map, 
			visible : true, 
			draggable : false, 
			icon : mysystemicon('line_point_delete.png', 16, 16, 24, 8),
		});
		for(var i = 0; i < linemarker[lid].length; i++){
			google.maps.event.clearListeners(linemarker[lid][i], 'dblclick');
		};
				var point= line[lid].getPath().getArray();
				for(var i = 0; i < point.length; i++){
					addlinemarkerevent(lid,i);
					linemarker[lid][i].setPosition(point[i]);
					linemarker[lid][i].setTitle('#' + i);	
				};
		controlerLine.getFormOption();
		line[lid].getLength();
});

google.maps.event.addListener(line[lid].getPath(), 'set_at', function(index) {
		line[lid].status = 'isedit';
		var point= line[lid].getPath().getArray();
		linemarker[lid][index].setPosition(point[index]);
		line[lid].getLength();
});
google.maps.event.addListener(line[lid].getPath(), 'remove_at', function(index) {
	line[lid].status = 'isedit';
	line[lid].getLength();
	google.maps.event.clearListeners(linemarker[lid][index], 'dblclick');
		linemarker[lid][index].setMap(null);
		linemarker[lid].splice(index, 1);
	for(var i = 0; i < linemarker[lid].length; i++){
		google.maps.event.clearListeners(linemarker[lid][i], 'dblclick');
	};
			var point= line[lid].getPath().getArray();
			for(var i = 0; i < point.length; i++){
				addlinemarkerevent(lid,i);
				linemarker[lid][i].setPosition(point[i]);
				linemarker[lid][i].setTitle('#' + i);	
			};
});
}
function getlinelength(){
	var factor = getSelectedValue('adminForm', 'jform_line_length');
	var wert = google.maps.geometry.spherical.computeLength(this.getPath());
	var	erg1 = Math.round((wert)/parseFloat(factor)*100)/100;
	var erg2 = Math.round((wert/1000)*100)/100;
	$('line_length').innerHTML = erg1;
	return erg2;	
}
function convertlinelength(factor){
	var lid = controlerLine.returnSelectedLine();
	if (lid === false) return;
	var wert = google.maps.geometry.spherical.computeLength(line[lid].getPath());	
	wert = Math.round((wert)/parseFloat(factor)*100)/100;
	$('line_length').innerHTML = wert;
	return wert;
}


function addlinemarkerevent(lid,lmid){
	google.maps.event.addListener(linemarker[lid][lmid], 'dblclick', function()
	{
		line[lid].getPath().removeAt(lmid);
	});
		google.maps.event.addListener(linemarker[lid][lmid], 'rightclick', function()
	{
	});

}
function linenew(newPath)
{
	showsubtab (0, 'line');
	controlerLine.clearLineSelection();
	var newlid = line.length;
	linemarker[newlid] = new Array();
	$('jform_line_title').value = Joomla.JText._('JS_LINE_TITLE_NEW_LINE');
	line[newlid] = new google.maps.Polyline(
	{
		map 			: map, 
		line_id 		: '', 
		gmselected 	: 'true', 
		status 		: 'isedit', 
		linetitel 		: $('jform_line_title').value, 
		strokeColor 	: '#000000', 
		strokeOpacity 	: 1.0, 
		strokeWeight 	: 1, 
		line_new 		: 'yes',
		firstinfofenster:'false',
		positinfowindowlat:'',
		positinfowindowlng:'',
		positinfowindow: 'false',
		chartunits		: 'SI',
		geodesic 		: true,
		editable		: true,
		text			:'' 
	});
	addmapevent(newlid);
	addlineevent(newlid);
	map.setOptions({draggableCursor:'crosshair'});
	line[newlid].getLength = getlinelength;
	line[newlid].getInfoWindow = getinfowindow;
	line[newlid].setChart = setlinechart;
	line[newlid].setFormOption = setlineformoption;
	if(newPath){
		line[newlid].setPath(newPath);
	}

}

function setlineedit(lid){
	var lid = controlerLine.returnSelectedLine();
		if(line[lid].oldstrokeColor != line[lid].strokeColor || line[lid].oldstrokeOpacity != line[lid].strokeOpacity || line[lid].oldstrokeWeight != line[lid].strokeWeight || line[lid].line_new == 'yes')
		{
			line[lid].status = 'isedit';
		}
}
//Methode
function setlineformoption()
{
	$('jform_line_farbe_linie').value = this.strokeColor;
	$('jform_line_title').value = this.linetitel;
	setSelectedValue('jform_line_linie_breite', this.strokeWeight);
	setSelectedValue('jform_line_transparent_linie', this.strokeOpacity);
	radionSetCheckedValue('jform_chart_on_off',this.chartonoff);
	document.getElementById('jform_line_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = this.text;
	radionSetCheckedValue('jform_line_infowindow_open',this.firstinfofenster);
	radionSetCheckedValue('jform_chart_units',this.chartunits);
}

var controlerLine ={
	clearLineSelection: function(option){
		for(var i = 0; i < line.length; i++){
			  line[i].setEditable(false);
			  line[i].gmselected = 'false';
			for(var p = 0; p < linemarker[i].length; p++){
				linemarker[i][p].setVisible(false);
			}
		   }
		 jQuery( "#map_elevation" ).slideUp( "slow");  
		this.setDefaultFormular(); 
		google.maps.event.clearListeners(map, 'click');
		map.setOptions({draggableCursor:''});
	},	
	returnSelectedLine: function(option){
		for(var i = 0; i < line.length; i++){
		  if (line[i].gmselected == 'true'){
			 return i; 
		  }};
		  return false;
	},	
	setDefaultFormular: function(option){
		$('jform_line_title').value = '';
		$('jform_line_farbe_linie').value ='#000000';
		setSelectedValue('jform_line_linie_breite', 1);
		setSelectedValue('jform_line_transparent_linie', 1.0);
		radionSetCheckedValue('jform_chart_on_off','false');
		$('line_length').innerHTML = '';
		document.getElementById('jform_line_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = '';
		radionSetCheckedValue('jform_chart_units','SI');
	},	
	setLineText: function(option){
		var lid = this.returnSelectedLine();
		if (lid === false) return;
		line[lid].status = 'isedit';
		line[lid].text = document.getElementById('jform_line_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
		line[lid].text = returnFullImagePath(line[lid].text);
		infowindow.setContent('<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+line[lid].text+'</div>');
		infowindow.open(map);
	},	
	deleteLineText: function(option){
		var lid =this.returnSelectedLine();
		if (lid === false) return;
		line[lid].status = 'isedit';
		line[lid].text = '';
		document.getElementById('jform_line_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML ='';
		infowindow.open(null);
	},
	getFormOption: function(option){
		var lid = this.returnSelectedLine();
		line[lid].linetitel = $('jform_line_title').value;
		line[lid].setOptions({
			strokeColor : $('jform_line_farbe_linie').value, 
			strokeWeight : $('jform_line_linie_breite').value, 
			strokeOpacity : $('jform_line_transparent_linie').value,
		});
		setlineedit();
	},
	setInfoWindowPosition: function(){
		var cid = this.returnSelectedLine();
		if (cid === false) return;
		line[cid].positinfowindow = line[cid].temppositinfowindow;
		line[cid].positinfowindowlat = infowindow.position.lat();
		line[cid].positinfowindowlng = infowindow.position.lng();
		line[cid].status = 'isedit';
		line[cid].getInfoWindow('default', 'Line');
		},
	deleteLinePosition: function(option){
		var cid = this.returnSelectedLine();
		if (cid === false) return;
		line[cid].positinfowindow = 'false';
		line[cid].positinfowindowlat = '';
		line[cid].positinfowindowlng = '';
		line[cid].status = 'isedit';
		line[cid].getInfoWindow('default', 'Line');
	},
	setInfoWindowOpen: function(option){
		var cid = this.returnSelectedLine();
		if (cid === false) return;
		main.InfoWindowOpen(cid,'line', option);
		},
	setChartDataUnits: function(option){
		var cid = this.returnSelectedLine();
		if (cid === false) return;
		line[cid].chartunits = option;
		line[cid].status = 'isedit';
		if (line[cid].chartonoff == 'true'){
			setChartHide();
			setChartShow();
		}
		},
	returnChartDataUnits: function(){
		var cid = this.returnSelectedLine();
		return line[cid].chartunits;
		},
}


function lineshow(lid)
{
	var linesetcenter = linemarker[lid][0].getPosition();
	map.setCenter(linesetcenter);
		controlerLine.clearLineSelection();
		line[lid].gmselected = 'true';
		line[lid].setFormOption();
}

function linedel (lid){
	$('jform_line_title').value = '';
	line[lid].status = 'del';
	line[lid].setMap(null);
	for(var p = 0; p < linemarker[lid].length; p++){
				linemarker[lid][p].setMap(null);
			}
			
			removedata('remove_line', line[lid].line_id);
			
	initlinetabelle();
	controlerLine.setDefaultFormular();
	controlerLine.clearLineSelection();
}

function selectedlinedelete(){
	var lid = controlerLine.returnSelectedLine();
	if (lid === false) return;
		if(line[lid].gmselected == 'true'){
			line[lid].setMap(null);
			for(var p = 0; p < linemarker[lid].length; p++){
				linemarker[lid][p].setMap(null);
			}
			removedata('remove_line', line[lid].line_id);
			line[lid].status = 'del';
		}
		controlerLine.setDefaultFormular();
		controlerLine.clearLineSelection();
}

function saveallline()
{
		
	var counter1 = 0;
	var counter2 = 0;
	controlerLine.clearLineSelection();
	for(var i = 0; i < line.length; i++){
		if (linemarker[i].length <= 1){
			line[i].status = 'del';
		}

		if(line[i].status != 'del' && line[i].status != 'standard' && linemarker[i].length > 2){
			counter1 += 1;
			}
		}
	if (counter1 != 0){	
		for(var i = 0; i < line.length; i++){
			if(line[i].status != 'del' && line[i].status != 'standard' && linemarker[i].length > 2){
				var punkte = '';
					for(var p = 0; p < linemarker[i].length; p++)
					{
						var lat = linemarker[i][p].position.lat();
						var lng = linemarker[i][p].position.lng();
						punkte += lat + ',' + lng + '|';
						linemarker[i][p].setMap(null);
					}
				counter2 += 1;
				if (counter1 > counter2){
					saveline(i, punkte);
				}else if(counter1 == counter2){
					var last ='true';
					saveline(i, punkte, last);
				}
			}
			for(var p = 0; p < linemarker[i].length; p++){
				linemarker[i][p].setMap(null);
			}
			line[i].setMap(null)
		}
	}else{
	 main.SaveProgress(14);	
	}
	controlerLine.setDefaultFormular();
}

//////////////elevation chart////////////////
function setlinechart() {
	function plotElevation(results, status, thisline) {
	  if (status != google.maps.ElevationStatus.OK) {
		alert(Joomla.JText._('JS_LINE_ERROR_NO_ELEVATION'));
		setChartHide();
		radionSetCheckedValue('jform_chart_on_off','false');
		return;
	  }
		if (controlerLine.returnChartDataUnits() == 'SI'){
			var lid = controlerLine.returnSelectedLine();
			var distanz = line[lid].getLength();
			titley = Joomla.JText._('JS_LINE_TITLE_AXE_Y_HEIGHT_SI');
			titlex = Joomla.JText._('JS_LINE_TITLE_AXE_X_DISTANZ_SI')
		}else{
			var lid = controlerLine.returnSelectedLine();
			var distanz = Math.round (line[lid].getLength()/parseFloat(1.609)*100)/100;
			titley = Joomla.JText._('JS_LINE_TITLE_AXE_Y_HEIGHT_ANGLO');
			titlex = Joomla.JText._('JS_LINE_TITLE_AXE_X_DISTANZ_ANGLO')
		}
	  var elevations = results;
	  var data = new google.visualization.DataTable();
	  data.addColumn('string', 'Sample');
	  data.addColumn('number', Joomla.JText._('JS_LINE_HEIGHT'));
	  for (var i = 0; i < results.length; i++) {
		  if (controlerLine.returnChartDataUnits() == 'SI'){
		 	data.addRow(['', Math.round((parseInt(elevations[i].elevation))/parseFloat(1)*100)/100]);
		  }else{
			data.addRow(['', Math.round((parseInt(elevations[i].elevation))/parseFloat(0.9144)*100)/100]);  
		  }
	  }
		var lid = controlerLine.returnSelectedLine();
	  jQuery( "#map_elevation" ).slideDown( "slow");	  
	  chart.draw(data, {
		height: 150,
		legend: 'true',
		titleY: titley,
		titleX: titlex + distanz
	  });
	}

	jQuery( "#map_elevation" ).slideUp( "slow");
	if(this.chartonoff == 'true'){
		chart = new google.visualization.LineChart(document.getElementById('map_elevation'));
		var pathRequest = {
						'path': this.getPath().getArray(),
						'samples': 500
						}
		elevator.getElevationAlongPath(pathRequest, plotElevation);	
	}			

}

function setChartHide(){
 var lid = controlerLine.returnSelectedLine();
	  if (lid === false) return;
		 jQuery( "#map_elevation" ).slideUp( "slow");
		  line[lid].chartonoff = 'false';
		  line[lid].status = 'isedit';
}
function setChartShow(){
 var lid = controlerLine.returnSelectedLine();
	  if (lid === false) return;
		  line[lid].chartonoff = 'true';
		  line[lid].status = 'isedit';
	line[lid].setChart();	  
}
