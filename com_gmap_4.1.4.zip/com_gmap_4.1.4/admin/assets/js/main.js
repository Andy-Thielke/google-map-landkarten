// JavaScript Document
var progresswert = 0;
var saveprogresswert = 0;
function initialize() {
	progress(0,'#loadbar');
	jQuery("#map_container" ).resizable();
	var $statusbar = jQuery("<div>", {id: "gmap-statusbar", class: "btn-toolbar"});
	var $gmap_center = jQuery("<div>", {id: "gmap-center", class: "btn-group"});
	var $gmap_center_lat = jQuery("<div>", {id: "gmap-center-lat", class: "badge"});
	var $gmap_center_lng = jQuery("<div>", {id: "gmap-center-lng", class: "badge"});
	var $gmap_zoom = jQuery("<div>", {id: "gmap-zoom", class: "btn-group"});
	var $gmap_zoom_level = jQuery("<div>", {id: "gmap-zoom-level", class: "badge"});
		jQuery("#status").prepend($statusbar);
		jQuery("#gmap-statusbar").append($gmap_center);
		jQuery("#gmap-statusbar").append($gmap_center_lat);
		jQuery("#gmap-statusbar").append($gmap_center_lng);
		jQuery("#gmap-statusbar").append($gmap_zoom);
		jQuery("#gmap-statusbar").append($gmap_zoom_level);
		jQuery("#gmap-center").html("Map Center:");
		jQuery("#gmap-zoom").html("Zoom Level:");
	$("jform_showelement_chzn").style.width='100%';

	if ($('jform_map_width').value != '') {
		$('map_container').style.width = $('jform_map_width').value;
		$('map_container').style.height = $('jform_map_height').value;
	}

	if ($('jform_map_center_lat').value == '') {
				get_default_option();
	}
	map = new google.maps.Map(document.getElementById('map'), init_map_option());
	map.folder_cluster_icon = $('jform_map_folder_cluster_icon').value || 'gm_cluster_adefault';
	map.cluster_icon = $('jform_map_cluster_icon').value || 'default.png';
	bike_layer = new google.maps.BicyclingLayer();
	traffic_layer = new google.maps.TrafficLayer();
	transit_layer = new google.maps.TransitLayer();
	weather_layer = new google.maps.weather.WeatherLayer();
	panoramio_layer = new google.maps.panoramio.PanoramioLayer();
	streetview_layer = map.getStreetView();
	geocoder = new google.maps.Geocoder();
	infowindow = new google.maps.InfoWindow();
	elevator = new google.maps.ElevationService();
	markercluster = new MarkerClusterer(map);
	var lang;
	var check = $('jform_custom_map_language').value == '' ?
		[
		lang = getSelectedValue('adminForm', 'jform_map_language')
		]:[
		lang = $('jform_custom_map_language').value,
		$('jform_custom_map_language').style.visibility='visible',
		]
	;
	getlang('gm_lang', 'form_ajax_lang', 'raw', 'getlang', lang);//View, Layout, Format, Ziel, Lang
	var option;		
		
	google.maps.event.addListener(map, 'tilesloaded', function() {
		jQuery("#map").append(maplang['map_button_html']);
		loadaccordion();					
		//Karten Optionen Laden//
		setmapoption.map_scrollwheel(radioGetCheckedValue('jform_map_scrollwheel', 'true'));
		setmapoption.map_DoubleClickZoom(radioGetCheckedValue('jform_map_DoubleClickZoom', 'true'));
		setmapoption.map_overview_map(radioGetCheckedValue('jform_map_overview_map', 'true'));
		setmapoption.map_overview_map_open(radioGetCheckedValue('jform_map_overview_map_open', 'true'));
		setmapoption.map_draggable(radioGetCheckedValue('jform_map_draggable', 'true'));
		setmapoption.map_panControl(radioGetCheckedValue('jform_map_panControl', 'true'));
		setmapoption.map_zoomControl(radioGetCheckedValue('jform_map_zoomControl'));
		setmapoption.map_ZoomControlStyle(getSelectedValue('adminForm', 'jform_map_ZoomControlStyle'));
		setmapoption.map_scaleControl(radioGetCheckedValue('jform_map_scaleControl', 'true'));
		setmapoption.streetViewControl(radioGetCheckedValue('jform_streetViewControl', 'true'));
		setmapoption.map_minzoom($('jform_map_minzoom').value);
		setmapoption.map_maxzoom($('jform_map_maxzoom').value);
		setmapoption.map_weather_temperature_unit(getSelectedValue('adminForm', 'jform_map_weather_temperature_unit'));
		setmapoption.map_weather_windspeed_unit(getSelectedValue('adminForm', 'jform_map_weather_windspeed_unit'));
		//Steuerbutton Optionen laden///
		setmapoption.map_setup_button(radioGetCheckedValue('jform_map_setup_button'));
		setmapoption.map_typ_control_button(radioGetCheckedValue('jform_map_typ_control_button'));
		setmapoption.map_layer_button(radioGetCheckedValue('jform_map_layer_button'));
		setmapoption.map_panoramio_button(radioGetCheckedValue('jform_map_panoramio_button'));
		//Layer Optionen laden//
		setmaplayer.maptyp(getSelectedValue('adminForm', 'jform_map_maptype'));
		setmapoption.satellite_view_45_heading(getSelectedValue('adminForm', 'jform_map_satellite_view_45_heading'));
		setmapoption.map_satellite_45(radioGetCheckedValue('jform_map_satellite_view_45', 'true45'));
		setmaplayer.map_bike_layer(radioGetCheckedValue('jform_map_bike_layer'));
		setmaplayer.map_traffic_layer(radioGetCheckedValue('jform_map_traffic_layer'));
		setmaplayer.map_transit_layer(radioGetCheckedValue('jform_map_transit_layer'));
		setmaplayer.map_weather_layer(radioGetCheckedValue('jform_map_weather_layer'));
		setmaplayer.map_panoramio_layer(radioGetCheckedValue('jform_map_panoramio_layer'));
		//StreetView laden//
		map_streetview.loadsaveddata();
		togglemapsetupview();
		drawingManager = new google.maps.drawing.DrawingManager({
			  drawingControl: false,
			});
		drawingManager.setMap(map);
	getdata('gm_editor', 'form_ajax_marker', 'raw', 'getallmarker','');//View, Layout, Format, Ziel, Lang
	getdata('gm_editor', 'form_ajax_rectangle', 'raw', 'getallrectangle', '');//View, Layout, Format, Ziel, Lang
	getdata('gm_editor', 'form_ajax_circle', 'raw', 'getallcircle','');//View, Layout, Format, Ziel, Lang
	getdata('gm_editor', 'form_ajax_line', 'raw', 'getallline','');//View, Layout, Format, Ziel, Lang
	getdata('gm_editor', 'form_ajax_polygon', 'raw', 'getallpolygon','');//View, Layout, Format, Ziel, Lang
	getdata('gm_editor', 'form_ajax_htmlbox', 'raw', 'getalltexte','');//View, Layout, Format, Ziel, Lang
	getkml('gm_editor', 'form_ajax_kml', 'raw');//View, Layout, Format
		var logoControlDiv = document.createElement('DIV');
		var logoControl = new MyLogoControl(logoControlDiv);
	logoControlDiv.index = 1; // used for ordering
	map.controls[google.maps.ControlPosition.LEFT_BOTTOM].push(logoControlDiv);
	});
	google.maps.event.addListener(map, 'dragend', function() {
		var mapcenter =  map.getCenter();
		jQuery("#gmap-center-lat").html("Latitude: " + mapcenter.lat());
		jQuery("#gmap-center-lng").html("Longitude: " + mapcenter.lng());
	});
	google.maps.event.addListener(map, 'zoom_changed', function() {
		jQuery("#gmap-zoom-level").html(map.getZoom());
	});
}

function progress(wert, bar) {
	progresswert = progresswert + wert;
	var progressbar = jQuery( bar ), progressLabel = jQuery( ".progress-label");
	progressbar.progressbar({
				value: false,
				change: function() {
						progressLabel.text( progressbar.progressbar( "value" ) + "%" );
						},
				complete: function() {
						progressLabel.text( "Complete!" );
						}
		});
	progressbar.progressbar( "value", progresswert );
	if (progresswert == 100){
		jQuery( bar ).slideUp( "slow");
		document.getElementById("map").style.visibility='visible';
	}
};

function returnstatuscheckbox (box) {
	if ($(box).checked) {
		return 'checked = "checked"';
	}
	else {
		return 'none';
	}
}
function statuscheckbox (box) {
	if ($(box).checked) {
		return true;
	}
	else {
		return false;
	}
}
function myicon(icon){
	var icon = new google.maps.MarkerImage(URIBase+'images/stories/com_gmap/' + icon);
	return icon;
	}

function returnFullImagePath (string){
	var newImageString = 'src="' + URIBase + 'images';
	var newString = string.replace(/src="images/g, newImageString);
	return newString;	
}
var main ={
		tableButtonShow: function(action, id){
						var buttonlink;
							buttonlink = '<a class="btn btn-mini" title="'
							buttonlink += Joomla.JText._('JS_MAIN_TABLE_BUTTON_TITLE_SHOW');
							buttonlink +='" href="#" onclick="';
							buttonlink += action;
							buttonlink +='(';
							buttonlink +=id;
							buttonlink +=');">';
							buttonlink +='<img class="assume" src="components/com_gmap/assets/images/eye.png" ';
							buttonlink +='width="12" height="12" />';
							buttonlink +=Joomla.JText._('JS_MAIN_TABLE_BUTTON_SHOW');
							buttonlink +='</a>';
						return buttonlink;	
		},
		tableButtonDelete: function(action, id){
						var buttonlink;
							buttonlink = '<a class="btn btn-mini" title="'
							buttonlink += Joomla.JText._('JS_MAIN_TABLE_BUTTON_TITLE_DELETE');
							buttonlink +='" href="#" onclick="';
							buttonlink += action;
							buttonlink +='(';
							buttonlink +=id;
							buttonlink +=');">';
							buttonlink +='<img class="assume" src="components/com_gmap/assets/images/reset.png" ';
							buttonlink +='width="12" height="12" />';
							buttonlink +=Joomla.JText._('JS_MAIN_TABLE_BUTTON_DELETE');
							buttonlink +='</a>';
						return buttonlink;	
		},
		tableButtonInfoWindow: function(action, parameter, isopen){
						if (isopen == 'checked'){
						var buttonlink;
							buttonlink = '<a class="btn btn-mini" title="'
							buttonlink += Joomla.JText._('JS_MAIN_TABLE_BUTTON_TITLE_INFOWINDOW_YES');
							buttonlink +='" href="#" onclick="';
							buttonlink += action;
							buttonlink +='(';
							buttonlink +=parameter;
							buttonlink +=');">';
							buttonlink +='<img class="assume" src="components/com_gmap/assets/images/yes.png" ';
							buttonlink +='width="12" height="12" />';
							buttonlink +=Joomla.JText._('JS_MAIN_TABLE_BUTTON_INFOWINDOW');
							buttonlink +='</a>';
						return buttonlink;
						}else{
						var buttonlink;
							buttonlink = '<a class="btn btn-mini" title="'
							buttonlink += Joomla.JText._('JS_MAIN_TABLE_BUTTON_TITLE_INFOWINDOW_NO');
							buttonlink +='" href="#" onclick="';
							buttonlink += action;
							buttonlink +='(';
							buttonlink +=parameter;
							buttonlink +=');">';
							buttonlink +='<img class="assume" src="components/com_gmap/assets/images/no.png" ';
							buttonlink +='width="12" height="12" />';
							buttonlink +=Joomla.JText._('JS_MAIN_TABLE_BUTTON_INFOWINDOW');
							buttonlink +='</a>';
						return buttonlink;
						}
		},
		ButtonInfoWindowPosition: function(action, parameter){
						var buttonlink;
							buttonlink = '<a class="btn btn-mini" title="'
							buttonlink += Joomla.JText._('JS_MAIN_TABLE_BUTTON_TITLE_INFOWINDOW_POSITION');
							buttonlink +='" href="#" onclick="';
							buttonlink += action;
							buttonlink +='(';
							buttonlink +=parameter;
							buttonlink +=');">';
							buttonlink +='<img class="assume" src="components/com_gmap/assets/images/yes.png" ';
							buttonlink +='width="12" height="12" />';
							buttonlink +=Joomla.JText._('JS_MAIN_TABLE_BUTTON_INFOWINDOW_POSITION');
							buttonlink +='</a>';
						return buttonlink;	
		},
		InfoWindowOpen: function(id, gmelement, option){
						var element = eval(gmelement);
						var status = element[id].firstinfofenster;
						for(var i = 0; i < marker.length; i++){
							if (marker[i].firstinfofenster == 'checked'){
								marker[i].firstinfofenster = '';
								marker[i].status = 'isedit';
							}
						}
						for(var i = 0; i < rectangle.length; i++){
							if (rectangle[i].firstinfofenster == 'checked'){
								rectangle[i].firstinfofenster = '';
								rectangle[i].status = 'isedit';
							}
						}
						for(var i = 0; i < circle.length; i++){
							if (circle[i].firstinfofenster == 'checked'){
								circle[i].firstinfofenster = '';
								circle[i].status = 'isedit';
							}
						}
						for(var i = 0; i < line.length; i++){
							if (line[i].firstinfofenster == 'checked'){
								line[i].firstinfofenster = '';
								line[i].status = 'isedit';
							}
						}
						for(var i = 0; i < polygon.length; i++){
							if (polygon[i].firstinfofenster == 'checked'){
								polygon[i].firstinfofenster = '';
								polygon[i].status = 'isedit';
							}
						}
						if (status == 'checked'){
							element[id].firstinfofenster = '';
							element[id].status = 'isedit';
						}else{
							element[id].firstinfofenster = 'checked';
							element[id].status = 'isedit';
						};
						initmarkertabelle();
						initrectangletabelle();
						initcircletabelle();
						initlinetabelle();
						initpolygontabelle();
						if (gmelement == 'rectangle'){
							getrectangleoption(id);
						}
						if (gmelement == 'circle'){
							getcircleoption(id);
						}
						if (gmelement == 'line'){
							line[id].setFormOption();
						}
						if (gmelement == 'polygon'){
							polygon[id].setFormOption();
						}
		},
		ShowElement: function(){
			
				if ($('jform_showelement')[0].selected){
					for(var i = 0; i < marker.length; i++){marker[i].setVisible(false)}
					controlerMarker.clearMarkerSelection();
				}else{
					for(var i = 0; i < marker.length; i++){
						if(marker[i].status != 'del'){marker[i].setVisible(true)}
					}
				}
				if ($('jform_showelement')[1].selected){
					for(var i = 0; i < rectangle.length; i++){rectangle[i].setVisible(false)}
					controlerRectangle.clearRectangleSelection();
				}else{
					for(var i = 0; i < rectangle.length; i++){
						if(rectangle[i].status != 'del'){rectangle[i].setVisible(true)}
					}
				}
				if ($('jform_showelement')[2].selected){
					for(var i = 0; i < circle.length; i++){circle[i].setVisible(false)}
					controlerCircle.clearCircleSelection();
				}else{
					for(var i = 0; i < circle.length; i++){
						if(circle[i].status != 'del'){circle[i].setVisible(true)}
					}
				}
				if ($('jform_showelement')[3].selected){
					for(var i = 0; i < line.length; i++){line[i].setVisible(false)}
					controlerLine.clearLineSelection();
				}else{
					for(var i = 0; i < line.length; i++){
						if(line[i].status != 'del'){line[i].setVisible(true)}
					}
				}
				if ($('jform_showelement')[4].selected){
					for(var i = 0; i < polygon.length; i++){polygon[i].setVisible(false)}
					controlerPolygon.clearPolygonSelection();
				}else{
					for(var i = 0; i < polygon.length; i++){
						if(polygon[i].status != 'del'){polygon[i].setVisible(true)}
					}
				}
				if ($('jform_showelement')[5].selected){
					setalltextnotactiv();
					for(var i = 0; i < textmarker.length; i++){textmarker[i].setVisible(false);text[i].setMap(null);}
				}else{
					for(var i = 0; i < textmarker.length; i++){
						if(textmarker[i].status != 'del'){textmarker[i].setVisible(true);text[i].setMap(map);}
					}
					setalltextnotactiv();
				}
				if ($('jform_showelement')[7].selected){
					markercluster.clearMarkers();
					for(var i = 0; i < marker.length; i++){
						marker[i].setMap(map);
					}
					google.maps.event.clearListeners(markercluster, 'mouseover');
				}else{
					controlerMarkerCluster.setClusterActiv();
					}
			},//ende ShowElement
			SaveAllElements: function(wert){
				saveprogresswert=0;
				save_map();
				saveallmarker();
				saveallrectangle();
				saveallcircle();
				saveallline();
				saveallpolygon();
				savealltext();
			},
			SaveProgress: function(wert){
				var progressLabel = jQuery( ".progress-label2");
				progressLabel.text( "Save..." );
				saveprogresswert = saveprogresswert+wert
				//progress(0,'#savebar');
				 jQuery( "#savebar" ).progressbar({
					 value: saveprogresswert,
					 complete: function() {
						progressLabel.text( "Complete!" );
						setTimeout(function () {
									document.getElementById('progress-label2').innerHTML = '';  
									 jQuery( "#savebar" ).progressbar("destroy");}, 1000);
						
						}
					 });
			}
}
function MyLogoControl(controlDiv) {
    controlDiv.style.padding = '5px';
	var logo = document.createElement('DIV');
	var logotext = '<a id="logo_button" title="Powered by joomla.de.com" target="new" href="http://www.joomla.de.com">';
		logotext+='<img src="components/com_gmap/assets/images/joomla-icon.png" /></a>';
	logo.innerHTML = logotext;
    logo.style.cursor = 'pointer';
    controlDiv.appendChild(logo);
}
function defaulticon(){
	var icon = new google.maps.MarkerImage(URIBase+'administrator/components/com_gmap/assets/images/pin_rot.png');
	return icon;
	}
function mysystemicon(icon, sizex, sizey, versatzx, versatzy){
	var icon = new google.maps.MarkerImage(URIBase+'administrator/components/com_gmap/assets/images/' + icon,
	new google.maps.Size(sizex, sizey),
	new google.maps.Point(0,0),
	new google.maps.Point(versatzx, versatzy)
	);   
	return icon;
	}
	
var cleartxt = {
    markertxt: function(){
        $('jform_marker_titel').value= '';
        $('jform_marker_ort').value = '';
        $('jform_marker_plz').value = '';
        $('jform_marker_strasse').value = '';
        $('jform_marker_lat').value = '';
        $('jform_marker_lng').value = '';
		$('jform_marker_mouseover').value = '';
		document.getElementById('jform_marker_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = '';
        },
    recangletxt: function(){
        $('jform_rectangle_marker1').value = '';
        $('jform_rectangle_marker2').value = '';
        },
    circletxt: function(){
        $('jform_circle_marker1').value = '';
        $('jform_circle_radius').value = '';
        },    
    linetxt: function(){
        $('jform_line_title').value= '';
        clearpointliste ();
        },
    texttxt: function(){
        $('jform_text_lat').value= '';
        $('jform_text_lng').value = '';
		document.getElementById('jform_text_box_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML =  '';   
		}
}	
//Methode
function getinfowindow(posit,element,tab){
	if (posit != 'default'){
		this.temppositinfowindow = posit.latLng;
	}
	
	if (this.positinfowindow != 'false'){
		infowindow.setOptions(
				{
				content : '<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+this.text+'</div>', 
				position : this.positinfowindow,
				pixelOffset:new google.maps.Size(0, 0)
				});
	}else{
		var addlink = main.ButtonInfoWindowPosition('controler'+element+'.setInfoWindowPosition');
		infowindow.setOptions(
				{
				content : '<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+this.text+addlink+'</div>', 
				position : this.temppositinfowindow,
				pixelOffset:new google.maps.Size(0, 0)
				});
	}
	if (this.text != '' && $('jform_showelement')[6].selected){ 	
		infowindow.open(map);	
	}else {
		infowindow.open(null);
	}
}
//Methode
function getbuttonwindow(posit){
			infowindow.setOptions(
					{
					content : this.text, 
					position : posit.latLng,
					});
			infowindow.open(map);	
}

// <?php !! This fools phpdocumentor into parsing this file
/**
* @version		$Id: joomla.javascript.js 14401 2010-01-26 14:10:00Z louis $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
* @license		GNU/GPL
* Joomla! is Free Software
*/
function gm_element(ele){
var my_gm_element = document.getElementById(ele);
return my_gm_element;
}

function getSelectedOption( frmName, srcListName ) {
	var form = eval( 'document.' + frmName );
	var srcList = eval( 'form.' + srcListName );

	i = srcList.selectedIndex;
	if (i != null && i > -1) {
		return srcList.options[i];
	} else {
		return null;
	}
}

function setSelectedValue(srcListName, value ) {
	var srcLen = $(srcListName).length;
	for (var i=0; i < srcLen; i++) {
		
		$(srcListName).options[i].selected = false;
		if ($(srcListName).options[i].value == value) {
			$(srcListName).options[i].selected = true;
			}
			
	}
	jQuery('#'+srcListName).trigger('liszt:updated');
}


function getSelectedValue( frmName, srcListName ) {
	var form = eval( 'document.' + frmName );
	var srcList = eval( 'form.' + srcListName );

	i = srcList.selectedIndex;
	if (i != null && i > -1) {
		return srcList.options[i].value;
	} else {
		return null;
	}
}

function getSelectedText( frmName, srcListName ) {
	var form = eval( 'document.' + frmName );
	var srcList = eval( 'form.' + srcListName );

	i = srcList.selectedIndex;
	if (i != null && i > -1) {
		return srcList.options[i].text;
	} else {
		return null;
	}
}

function radioGetCheckedValue(radioObj,convert) {
		if ($(radioObj+'0').checked) {
			if (convert == 'true45'){
				return 45;
			}
			if (convert == 'true'){
				return true;
			}else{
				return $(radioObj+'0').value;	
			}
		} else {
			if (convert == 'true45'){
				return 0;
			}
			if (convert == 'true'){
				return false;
			}else{
				return $(radioObj+'1').value;	
			}
		}
}

function radionSetCheckedValue(radioObj,option){
	if (option == 'true' || option == 'checked' || option == 'SI'){
		jQuery('#'+ radioObj+'0').next('label').addClass('btn active btn-success');
		jQuery('#'+ radioObj+'0').prop("checked", true);
		jQuery('#'+ radioObj+'1').next('label').removeClass('active btn-success');
		jQuery('#'+ radioObj+'1').next('label').addClass('btn');
		jQuery('#'+ radioObj+'1').prop("checked", false);
	} else if (option == 'false' || option == '' || option == 'ANGLO'){
		jQuery('#'+ radioObj+'0').next('label').removeClass('btn active btn-success');
		jQuery('#'+ radioObj+'0').next('label').addClass('btn');
		jQuery('#'+ radioObj+'0').prop("checked", false);
		jQuery('#'+ radioObj+'1').next('label').addClass('btn active btn-success');
		jQuery('#'+ radioObj+'1').prop("checked", true);
	}
}