// JavaScript Document

function showpolygon()
{
	setalltextnotactiv();
	controlerRectangle.clearRectangleSelection();
	controlerCircle.clearCircleSelection();
	controlerMarker.clearMarkerSelection();
	controlerLine.clearLineSelection();
	showtab(6);
	google.maps.event.clearListeners(map, 'click');
}


function initpolygon()
{
	for(var i = 0; i < polygon.length; i++)
	{
		//add new Methods
		polygon[i].getLength = getpolygonlength;
		polygon[i].getArea = getpolygonarea;
		polygon[i].getInfoWindow = getinfowindow;
		polygon[i].setFormOption = setpolyformoption;
		//ende
		
		addpolygonevent(i);
		for(var p = 0; p < polygonmarker[i].length; p++)
		{
			addpolygonmarkerevent(i, p);
		}
	}
	initpolygontabelle();
	controlerPolygon.clearPolygonSelection();

}

function initpolygontabelle() {
  var data = new google.visualization.DataTable();
  data.addColumn('number', 'ID');
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_TITLE'));
  data.addColumn('string', Joomla.JText._('JS_POLYGON_HEADER_TABLE_LINE_LENGTH'));
   data.addColumn('string', Joomla.JText._('JS_POLYGON_HEADER_TABLE_AREA'));
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_EDIT'));
  var count = 0;
  for(var i = 0; i < polygon.length; i++){
		if(polygon[i].status != 'del'){
			data.addRows(1);
			data.setCell(count, 0, i+1);
			data.setCell(count, 1, polygon[i].polygontitel);
			data.setCell(count, 2, polygon[i].getLength()+' km');
			data.setCell(count, 3, polygon[i].getArea()+' km²');
			data.setCell(count, 4, main.tableButtonShow('polygonshow',i)+main.tableButtonDelete('polygondel',i)+main.tableButtonInfoWindow('main.InfoWindowOpen',i+', polygon', polygon[i].firstinfofenster));
		count++;
		}
		} 
 var table = new google.visualization.Table(document.getElementById('page_polygontabelle'));
var view = new google.visualization.DataView(data);
  table.draw(view, {allowHtml: true, showRowNumber: false,cssClassNames: 'cssClassNames'});
 table.setSelection([{'row': controlerPolygon.returnSelectedPolygon()}]);
}


function addpolygonmapevent(lid)
{
	google.maps.event.clearListeners(map, 'click');
	google.maps.event.addListener(map, 'click', function(event)
	{
		var newpoint = event.latLng;
		var path = polygon[lid].getPath();
		path.push(newpoint);
		polygon[lid].setPath(path);
	});
	google.maps.event.clearListeners(map, 'rightclick');
	google.maps.event.addListener(map, 'rightclick', function(event)
	{
		google.maps.event.clearListeners(map, 'click');
		map.setOptions({draggableCursor:''});
		polygon[lid].setEditable(false);
		controlerPolygon.clearPolygonSelection();
		$('polygon_line_length').innerHTML = '';
		for(var p = 0; p < polygonmarker[lid].length; p++){
			polygonmarker[lid][p].setVisible(false);
		}
	});
}

function addpolygonevent(lid)
{
	
	google.maps.event.addListener(polygon[lid], 'click', function(event)
	{
		showpolygon();
		map.setOptions({draggableCursor:'crosshair'});
		polygon[lid].gmselected = 'true';
		addpolygonmapevent(lid);
		for(var p = 0; p < polygonmarker[lid].length; p++){
			polygonmarker[lid][p].setVisible(true);
		}
		polygon[lid].setEditable(true);
		polygon[lid].getInfoWindow(event, 'Polygon');
		polygon[lid].setFormOption();
		initpolygontabelle();
		polygon[lid].getLength();
		polygon[lid].getArea();
	});

	google.maps.event.addListener(polygon[lid].getPath(), 'insert_at', function(index) {
		polygon[lid].status = 'isedit';
		var point= polygon[lid].getPath().getArray();
		polygonmarker[lid][polygonmarker[lid].length] = new google.maps.Marker({
			position : point[index],
			title : '#' + index, 
			map : map, 
			visible : true, 
			draggable : false, 
			icon : mysystemicon('line_point_delete.png', 16, 16, 24, 8),
		});
		
		for(var i = 0; i < polygonmarker[lid].length; i++){
			google.maps.event.clearListeners(polygonmarker[lid][i], 'dblclick');
		};
				var point= polygon[lid].getPath().getArray();
				for(var i = 0; i < point.length; i++){
					addpolygonmarkerevent(lid,i);
					polygonmarker[lid][i].setPosition(point[i]);
					polygonmarker[lid][i].setTitle('#' + i);	
				};
		controlerPolygon.getFormOption();
		infowindow.open(null);
		polygon[lid].getLength();
		polygon[lid].getArea();
});

google.maps.event.addListener(polygon[lid].getPath(), 'set_at', function(index) {
		polygon[lid].status = 'isedit';
		infowindow.open(null);
		var point= polygon[lid].getPath().getArray();
		polygonmarker[lid][index].setPosition(point[index]);
		polygon[lid].getLength();
		polygon[lid].getArea();
});
google.maps.event.addListener(polygon[lid].getPath(), 'remove_at', function(index) {
	polygon[lid].status = 'isedit';
	polygon[lid].getLength();
	polygon[lid].getArea();
	google.maps.event.clearListeners(polygonmarker[lid][index], 'dblclick');
		polygonmarker[lid][index].setMap(null);
		polygonmarker[lid].splice(index, 1);
	for(var i = 0; i < polygonmarker[lid].length; i++){
		google.maps.event.clearListeners(polygonmarker[lid][i], 'dblclick');
	};
			var point= polygon[lid].getPath().getArray();
			for(var i = 0; i < point.length; i++){
				addpolygonmarkerevent(lid,i);
				polygonmarker[lid][i].setPosition(point[i]);
				polygonmarker[lid][i].setTitle('#' + i);	
			};
});
}
function getpolygonlength(){
	var factor = getSelectedValue('adminForm', 'jform_polygon_line_length');
	var firstpoint = this.getPath().getArray();
	if (firstpoint.length >= 3){
		var wert1 = google.maps.geometry.spherical.computeLength(this.getPath());	
		var wert2 = google.maps.geometry.spherical.computeDistanceBetween(firstpoint[0],firstpoint[firstpoint.length-1]);
		var erg = Math.round((wert1 + wert2)/parseFloat(factor)*100)/100;
		var erg2 = parseInt(wert1 + wert2)/1000;
		$('polygon_line_length').innerHTML = erg;
		return erg2;
	}
}

function getpolygonarea(){
	var factor = getSelectedValue('adminForm', 'jform_polygon_area');
	var firstpoint = this.getPath().getArray();
	if (firstpoint.length >= 3){
		var wert1 = google.maps.geometry.spherical.computeArea(this.getPath());
		var erg = Math.round((wert1)/parseFloat(factor)*100)/100;	
		var erg2 = parseInt((wert1/10000))/100;
		$('polygon_area').innerHTML = erg;
		return erg2;
		
	}
}

function convertpolygonlength(factor){
	var poly = controlerPolygon.returnSelectedPolygon();
	if (poly === false) return;
	var firstpoint = polygon[poly].getPath().getArray();
	if (firstpoint.length >= 3){
		var wert1 = google.maps.geometry.spherical.computeLength(polygon[poly].getPath());	
		var wert2 = google.maps.geometry.spherical.computeDistanceBetween(firstpoint[0],firstpoint[firstpoint.length-1]);
		var erg = Math.round((wert1 + wert2)/parseFloat(factor)*100)/100;
		$('polygon_line_length').innerHTML = erg;
	}
}

function convertpolygonarea(factor){
	var poly = controlerPolygon.returnSelectedPolygon();
	if (poly === false) return;
	var firstpoint = polygon[poly].getPath().getArray();
	if (firstpoint.length >= 3){
		var wert1 = google.maps.geometry.spherical.computeArea(polygon[poly].getPath());	
		var erg = Math.round((wert1)/parseFloat(factor)*100)/100;
		$('polygon_area').innerHTML = erg;
	}
}

function addpolygonmarkerevent(lid,lmid){
	polygonmarker[lid][lmid].getButtonWindow = getbuttonwindow;
	google.maps.event.addListener(polygonmarker[lid][lmid], 'dblclick', function()
	{	infowindow.open(null);
		polygon[lid].getPath().removeAt(lmid);
	});
	google.maps.event.addListener(polygonmarker[lid][lmid], 'click', function()
	{	infowindow.open(null);
	});
		google.maps.event.addListener(polygonmarker[lid][lmid], 'rightclick', function(event)
	{
		//this.text = main.tableButtonDelete('polygondel',i);
		//this.getButtonWindow(event);
	});

}
function polygonnew()
{
	showsubtab (0, 'polygon');
	controlerPolygon.clearPolygonSelection();
	var newlid = polygon.length;
	polygonmarker[newlid] = new Array();
	$('jform_polygon_title').value = Joomla.JText._('JS_POLYGON_TITLE_NEW_polygon');
	polygon[newlid] = new google.maps.Polygon(
	{
		map 			: map, 
		polygon_id 		: '', 
		gmselected : 'true', 
		status 	: 'isedit', 
		polygontitel 	: $('jform_polygon_title').value, 
		strokeColor 	: '#000000', 
		strokeOpacity 	: 1.0, 
		strokeWeight 	: 1,
		fillColor 		: '',
		fillOpacity		: 0.0,
		polygon_new 	: 'yes',
		positinfowindow: 'false',
		positinfowindowlat:'',
		positinfowindowlng:'',
		geodesic 		: true,
		editable		: true,
		text			:'' 
	});
	addpolygonmapevent(newlid);
	addpolygonevent(newlid);
	map.setOptions({draggableCursor:'crosshair'});
	polygon[newlid].getLength = getpolygonlength;
	polygon[newlid].getArea = getpolygonarea;
	polygon[newlid].getInfoWindow = getinfowindow;
	polygon[newlid].setFormOption = setpolyformoption;
}

function setpolygonedit(lid){
	var lid = controlerPolygon.returnSelectedPolygon();
		if(polygon[lid].oldstrokeColor != polygon[lid].strokeColor || polygon[lid].oldstrokeOpacity != polygon[lid].strokeOpacity || polygon[lid].oldstrokeWeight != polygon[lid].strokeWeight || polygon[lid].polygon_new == 'yes' || polygon[rid].oldfillColor != polygon[rid].fillColor || polygon[rid].oldfillOpacity != polygon[rid].fillOpacity)
		{
			polygon[lid].status = 'isedit';
		}
}
//Methode
function setpolyformoption()
{
	$('jform_polygon_color_line').value = this.strokeColor;
	$('jform_polygon_title').value = this.polygontitel;
	setSelectedValue('jform_polygon_width_line', this.strokeWeight);
	setSelectedValue('jform_polygon_transparent_line', this.strokeOpacity);
	$('jform_polygon_color_fill').value = this.fillColor;
	setSelectedValue('jform_polygon_transparent_fill', this.fillOpacity);
	document.getElementById('jform_polygon_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = this.text;
	radionSetCheckedValue('jform_polygon_infowindow_open',this.firstinfofenster);
}

var controlerPolygon ={
	clearPolygonSelection: function(option){
		for(var i = 0; i < polygon.length; i++){
			  polygon[i].setEditable(false);
			  polygon[i].gmselected = 'false';
			for(var p = 0; p < polygonmarker[i].length; p++){
				polygonmarker[i][p].setVisible(false);
			}
		   }
		this.setDefaultFormular();
		infowindow.open(null);
		google.maps.event.clearListeners(map, 'click');
		map.setOptions({draggableCursor:''});
	},	
	returnSelectedPolygon: function(option){
		for(var i = 0; i < polygon.length; i++){
		  if (polygon[i].gmselected == 'true'){
			 return i; 
		  }};
		  return false;
	},	
	setDefaultFormular: function(option){
		$('jform_polygon_title').value = '';
		$('jform_polygon_color_line').value ='#000000';
		setSelectedValue('jform_polygon_width_line', 1);
		setSelectedValue('jform_polygon_transparent_line', 1.0);
		$('jform_polygon_color_fill').value = '';
		setSelectedValue('jform_polygon_transparent_fill', 1.0);
		$('polygon_line_length').innerHTML = '';
		$('polygon_area').innerHTML = '';
		document.getElementById('jform_polygon_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = '';
		},	
	setPolygonText: function(option){
		var lid = this.returnSelectedPolygon();
		if (lid === false) return;
		polygon[lid].status = 'isedit';
		polygon[lid].text = document.getElementById('jform_polygon_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
		polygon[lid].text = returnFullImagePath(polygon[lid].text);
		infowindow.setContent('<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+polygon[lid].text+'</div>');
		infowindow.open(map);
	},	
	deletePolygonText: function(option){
		var lid =this.returnSelectedPolygon();
		if (lid === false) return;
		polygon[lid].status = 'isedit';
		polygon[lid].text = '';
		document.getElementById('jform_polygon_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML ='';
		infowindow.open(null);
	},
	getFormOption: function(option){
		var lid = this.returnSelectedPolygon();
		polygon[lid].polygontitel = $('jform_polygon_title').value;
		polygon[lid].setOptions({
			strokeColor : $('jform_polygon_color_line').value, 
			strokeWeight : $('jform_polygon_width_line').value, 
			strokeOpacity : $('jform_polygon_transparent_line').value,
			fillColor : $('jform_polygon_color_fill').value, 
			fillOpacity : $('jform_polygon_transparent_fill').value, 
		});
		if($('jform_polygon_color_fill').value == ''){
			polygon[lid].setOptions({
				fillOpacity : 0.0,
				});
		}
		setpolygonedit();
	},
	setInfoWindowPosition: function(){
		var cid = this.returnSelectedPolygon();
		if (cid === false) return;
		polygon[cid].positinfowindow = polygon[cid].temppositinfowindow;
		polygon[cid].positinfowindowlat = infowindow.position.lat();
		polygon[cid].positinfowindowlng = infowindow.position.lng();
		polygon[cid].status = 'isedit';
		polygon[cid].getInfoWindow('default', 'Polygon');
		},
	deletePolygonPosition: function(option){
		var cid = this.returnSelectedPolygon();
		if (cid === false) return;
		polygon[cid].positinfowindow = 'false';
		polygon[cid].positinfowindowlat = '';
		polygon[cid].positinfowindowlng = '';
		polygon[cid].status = 'isedit';
		polygon[cid].getInfoWindow('default', 'Polygon');
	},
	setInfoWindowOpen: function(option){
		var cid = this.returnSelectedPolygon();
		if (cid === false) return;
		main.InfoWindowOpen(cid,'polygon', option);
		},
					
}


function polygonshow(lid)
{
	var polygonsetcenter = polygonmarker[lid][0].getPosition();
	map.setCenter(polygonsetcenter);
		controlerPolygon.clearPolygonSelection();
		
}

function polygondel (lid){
	$('jform_polygon_title').value = '';
	polygon[lid].status = 'del';
	polygon[lid].setMap(null);
	for(var p = 0; p < polygonmarker[lid].length; p++){
				polygonmarker[lid][p].setMap(null);
			}
			
			removedata('remove_polygon', polygon[lid].polygon_id);
			
	initpolygontabelle();
}

function selectedpolygondelete(){
	var lid = controlerPolygon.returnSelectedPolygon();
	if (lid === false) return;
		if(polygon[lid].gmselected == 'true'){
			polygon[lid].setMap(null);
			for(var p = 0; p < polygonmarker[lid].length; p++){
				polygonmarker[lid][p].setMap(null);
			}
			removedata('remove_polygon', polygon[lid].polygon_id);
			polygon[lid].status = 'del';
		}
		controlerPolygon.setDefaultFormular();
}

function saveallpolygon()
{
		
	var counter1 = 0;
	var counter2 = 0;
	controlerPolygon.clearPolygonSelection();
	
	for(var i = 0; i < polygon.length; i++){
		if (polygonmarker[i].length <= 2){
			polygon[i].status = 'del';
		}
		if(polygon[i].status != 'del' && polygon[i].status != 'standard'){
			counter1 += 1;
			}
		}
	if (counter1 != 0){	
		for(var i = 0; i < polygon.length; i++){
			if(polygon[i].status != 'del' && polygon[i].status != 'standard'){
				var punkte = '';
					for(var p = 0; p < polygonmarker[i].length; p++)
					{
						var lat = polygonmarker[i][p].position.lat();
						var lng = polygonmarker[i][p].position.lng();
						punkte += lat + ',' + lng + '|';
						polygonmarker[i][p].setMap(null);
					}
				counter2 += 1;
				if (counter1 > counter2){
					savepolygon(i, punkte);
				}else if(counter1 == counter2){
					var last ='true';
					savepolygon(i, punkte, last);
				}
			}
			for(var p = 0; p < polygonmarker[i].length; p++){
				polygonmarker[i][p].setMap(null);
			}
			polygon[i].setMap(null)
		}
	}else{
	 main.SaveProgress(14);	
	}
	
}


