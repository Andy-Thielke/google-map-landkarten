var marker1 = new Array();
var marker2 = new Array();

function showrectangletabelle()
{
	//showsubtab (33, 31, 33, 'rectangle');
	initrectangletabelle();
}

function showrectangle()
{
	controlerMarker.clearMarkerSelection();
	setalltextnotactiv();
	controlerCircle.clearCircleSelection();
	controlerLine.clearLineSelection();
	controlerPolygon.clearPolygonSelection();
	google.maps.event.clearListeners(map, 'click');
	showtab(3);
}

function initrectangle()
{

	for(var i = 0; i < rectangle.length; i++)
	{
		rectangle[i].getInfoWindow = getinfowindow;//from main
		addrectangleevent(i);
	}

	initrectangletabelle();
}

function initrectangletabelle() {
	
  var data = new google.visualization.DataTable();
  data.addColumn('number', 'ID');
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_EDIT'));
  var count = 0;
  for(var i = 0; i < rectangle.length; i++){
		if(rectangle[i].status != 'del'){
			data.addRows(1);
			data.setCell(count, 0, i+1);
			data.setCell(count, 1, main.tableButtonShow('rectangleshow',i)+main.tableButtonDelete('rectangledel',i)+main.tableButtonInfoWindow('main.InfoWindowOpen',i+', \'rectangle\'', rectangle[i].firstinfofenster));
		count++;
		}
		} 
 var table = new google.visualization.Table(document.getElementById('page_rectangletabelle'));
var view = new google.visualization.DataView(data);
  table.draw(view, {allowHtml: true, showRowNumber: false,cssClassNames: 'cssClassNames'});
 table.setSelection([{'row': controlerRectangle.returnSelectedRectangle()}]);
}

function addrectangleevent(rid)
{
	google.maps.event.addListener(rectangle[rid], 'click', function(event)
	{
		showrectangle();
		controlerRectangle.clearRectangleSelection();
		rectangle[rid].gmselected = 'true';
		getrectangleoption(rid);
		rectangle[rid].setEditable(true);
		rectangle[rid].setDraggable(true);
		rectangle[rid].getInfoWindow(event, 'Rectangle');
		initrectangletabelle();
		
	});
	google.maps.event.addListener(rectangle[rid], 'bounds_changed', function()
	{
		rectangle[rid].status = 'isedit';
	});
	google.maps.event.addListener(rectangle[rid], 'dragend', function()
	{
		rectangle[rid].status = 'isedit';
	});
}

function rectanglenew(){
	showsubtab (0, 'rectangle');
	controlerRectangle.clearRectangleSelection();
	google.maps.event.clearListeners(drawingManager, 'rectanglecomplete');
	drawingManager.setDrawingMode(google.maps.drawing.OverlayType.RECTANGLE);
	drawingManager.setOptions({rectangleOptions:{
		fillColor: '',
		fillOpacity: '',
		strokeWeight: 1,
		clickable: false,
		zIndex: 1,
		editable: true
	}})
google.maps.event.addListener(drawingManager, 'rectanglecomplete', function(rect) {
	drawingManager.setDrawingMode(null);
	var newrid = rectangle.length;
	rectangle[newrid] = new google.maps.Rectangle(
	{
		map : map, 
		rectangle_id : '', 
		gmselected : 'true', 
		status : 'isedit', 
		fillColor : '', 
		fillOpacity : 0.0, 
		strokeColor : '#000000', 
		strokeOpacity : 1.0, 
		strokeWeight : 1, 
		rectangle_new : 'yes', 
		editable: true,
		firstinfofenster:'false',
		positinfowindowlat:'',
		positinfowindowlng:'',
		positinfowindow: 'false',
		draggable: true,
		text:''
	});
	var currentBounds = rect.getBounds();
	var latLngBounds = new google.maps.LatLngBounds(currentBounds.getSouthWest(), currentBounds.getNorthEast());
	rectangle[newrid].setBounds(latLngBounds);
	rectangle[newrid].getInfoWindow = getinfowindow;
	rect.setMap(null);
	addrectangleevent(newrid);
});	
}

function setrectangleedit(rid)
{
	if(rectangle[rid].oldfillColor != rectangle[rid].fillColor || rectangle[rid].oldfillOpacity != rectangle[rid].fillOpacity || rectangle[rid].oldstrokeColor != rectangle[rid].strokeColor || rectangle[rid].oldstrokeOpacity != rectangle[rid].strokeOpacity || rectangle[rid].oldstrokeWeight != rectangle[rid].strokeWeight || rectangle[rid].rectangle_new == 'yes')
	{
		rectangle[rid].status = 'isedit';
	}
}

var controlerRectangle ={
	clearRectangleSelection:function(option){
		for(var i = 0; i < rectangle.length; i++){
			  rectangle[i].setEditable(false);
			   rectangle[i].setDraggable(false);
			  rectangle[i].gmselected = 'false';
			  infowindow.open(null);
		}
	},	
	returnSelectedRectangle: function(option){
		for(var i = 0; i < rectangle.length; i++){
		  if (rectangle[i].gmselected == 'true'){
			 return i; 
		  }};
		  return false;
	},	
	setRectangleText: function(option){
		var cid = this.returnSelectedRectangle();
		if (cid === false) return;
		rectangle[cid].status = 'isedit';
		rectangle[cid].text = document.getElementById('jform_rectangle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
		rectangle[cid].text = returnFullImagePath(rectangle[cid].text);
		rectangle[cid].getInfoWindow('default', 'Rectangle');
		infowindow.open(map);
	},	
	deleteRectanglePosition: function(option){
		var cid = this.returnSelectedRectangle();
		if (cid === false) return;
		rectangle[cid].positinfowindow = 'false';
		rectangle[cid].positinfowindowlat = '';
		rectangle[cid].positinfowindowlng = '';
		rectangle[cid].status = 'isedit';
		rectangle[cid].getInfoWindow('default', 'Rectangle');
	},	
	deleteRectangleText: function(option){
		var cid =this.returnSelectedRectangle();
		if (cid === false) return;
		rectangle[cid].status = 'isedit';
		rectangle[cid].text = '';
		document.getElementById('jform_rectangle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML ='';
		infowindow.open(null);
	},
	setInfoWindowPosition: function(){
		var cid = this.returnSelectedRectangle();
		if (cid === false) return;
		rectangle[cid].positinfowindow = rectangle[cid].temppositinfowindow;
		rectangle[cid].positinfowindowlat = infowindow.position.lat();
		rectangle[cid].positinfowindowlng = infowindow.position.lng();
		rectangle[cid].status = 'isedit';
		rectangle[cid].getInfoWindow('default', 'Rectangle');
		},
	setInfoWindowOpen: function(option){
		var cid = this.returnSelectedRectangle();
		if (cid === false) return;
		main.InfoWindowOpen(cid,'rectangle', option);
		},
}


function setrectangleoption(option)
{
		var farbefuellung = $('jform_rectangle_farbe_fuellung').value;
		var fuellungtrans = getSelectedValue('adminForm', 'jform_rectangle_transparent_fuellung') ;
		if(farbefuellung == '')
		{
			fuellungtrans = 0.0;
		}
	for(var i = 0; i < rectangle.length; i++){
		if (rectangle[i].gmselected == 'true'){
		rectangle[i].setOptions(
		{
			strokeColor : $('jform_rectangle_farbe_linie').value, 
			strokeWeight : getSelectedValue('adminForm', 'jform_rectangle_linie_breite'), 
			strokeOpacity :getSelectedValue('adminForm', 'jform_rectangle_transparent_linie'), 
			fillColor : $('jform_rectangle_farbe_fuellung').value, 
			fillOpacity :fuellungtrans 
		});
		setrectangleedit(i);
		}
	}
}


function getrectangleoption(rid)
{
	$('jform_rectangle_farbe_linie').value = rectangle[rid].strokeColor;
	setSelectedValue('jform_rectangle_linie_breite', rectangle[rid].strokeWeight);
	setSelectedValue('jform_rectangle_transparent_linie', rectangle[rid].strokeOpacity);
	$('jform_rectangle_farbe_fuellung').value = rectangle[rid].fillColor;
	setSelectedValue('jform_rectangle_transparent_fuellung', rectangle[rid].fillOpacity);
	document.getElementById('jform_rectangle_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML =  rectangle[rid].text;
	radionSetCheckedValue('jform_rectangle_infowindow_open',rectangle[rid].firstinfofenster);

}

function rectangleshow(rid)
{
	rectangle[rid].gmselected = 'true';
	var currentBounds = rectangle[rid].getBounds();
	var topLeftLatLng = new google.maps.LatLng( currentBounds.getNorthEast().lat(),
                                                currentBounds.getSouthWest().lng());
	map.setCenter(topLeftLatLng);
	controlerRectangle.clearRectangleSelection();
	rectangle[rid].gmselected = 'true';
	getrectangleoption(rid);
	rectangle[rid].setEditable(true);
	rectangle[rid].setDraggable(true);
}

function rectangledel (rid){
			rectangle[rid].setMap(null);
			removedata('remove_rectangle', rectangle[rid].rectangle_id);
			rectangle[rid].status = 'del'
initrectangletabelle();
}
function selectedrectangledelete()
{
	for(var i = 0; i < rectangle.length; i++)
	{
		if(rectangle[i].gmselected == 'true')
		{
			rectangle[i].setMap(null);
			removedata('remove_rectangle', rectangle[i].rectangle_id);
			rectangle[i].status = 'del'
		}
	}

	initrectangletabelle();
}

function saveallrectangle(){
	
	var counter1 = 0;
	var counter2 = 0;
	controlerRectangle.clearRectangleSelection();
	for(var i = 0; i < rectangle.length; i++){
		if(rectangle[i].status != 'del' && rectangle[i].status != 'standard'){
			counter1 += 1;
			}
		}
	if (counter1 != 0){	
		for(var i = 0; i < rectangle.length; i++){
			if(rectangle[i].status != 'del' && rectangle[i].status != 'standard'){
				counter2 += 1;
				if (counter1 > counter2){
					saverectangle(i);
				}else if(counter1 == counter2){
					var last ='true';
					saverectangle(i, last);
				}
			}
			rectangle[i].setMap(null)
		}
	}else{
	 main.SaveProgress(14);	
	}
}

