var selectedmarkericondir = '';
var selectedmarkericonfile = '';

function showmarker()
{
	controlerRectangle.clearRectangleSelection();
	controlerCircle.clearCircleSelection();
	controlerLine.clearLineSelection();
	controlerPolygon.clearPolygonSelection();
	google.maps.event.clearListeners(map, 'click');
	setalltextnotactiv();
	showtab(2)
}

function initmarkertabelle() {
  var data = new google.visualization.DataTable();
  data.addColumn('number', 'ID');
  data.addColumn('string', Joomla.JText._('JS_MARKER_HEADER_TABLE_ICON'));
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_TITLE'));
  data.addColumn('string', Joomla.JText._('JS_MAIN_HEADER_TABLE_EDIT'));
  var count = 0;
  for(var i = 0; i < marker.length; i++){
		if(marker[i].status != 'del'){
			var geticon = '<img src="../images/stories/com_gmap/' + marker[i].markericon + '" title="Icon" />';
			if(marker[i].markericon == 'standard'){
				geticon = '<img src="../administrator/components/com_gmap/assets/images/pin_rot.png" title="Standard Icon" />'
			}
			data.addRows(1);
			data.setCell(count, 0, i+1);
			data.setCell(count, 1, geticon);
			data.setCell(count, 2, marker[i].markertitel);
			data.setCell(count, 3, main.tableButtonShow('markershow',i)+main.tableButtonDelete('markerdel',i)+main.tableButtonInfoWindow('main.InfoWindowOpen',i+', marker', marker[i].firstinfofenster));
		count++;
		}
		} 
 var table = new google.visualization.Table(document.getElementById('page_markertabelle'));
var view = new google.visualization.DataView(data);
  table.draw(view, {allowHtml: true, showRowNumber: false,cssClassNames: 'cssClassNames'});
 table.setSelection([{'row': controlerMarker.returnSelectedMarker()}]);
}


function initmarker(){
	for(var i = 0; i < marker.length; i++){
		addmarkerevent(i);
	}
	initmarkertabelle()
}


function moveAdresse()
{
	var BText = '<p style="font-family: arial,helvetica,sans-serif; font-size: 12px; line-height: normal; color: #000000; padding: 0px; margin: 0px;"><strong>' + $('jform_marker_titel').value + '</strong><br />' +  $('jform_marker_strasse').value + '<br />' + $('jform_marker_plz').value + ' ' + $('jform_marker_ort').value + '</p>';
	document.getElementById('jform_marker_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = BText;
	showsubtab (1, 'marker');
}

function refreshicontree (mid, scrollen){
	if (marker[mid].markericon != 'standard') {
		var pfadfile = marker[mid].markericon.split("/");
    var jsimg='../images/stories/com_gmap/'+ marker[mid].markericon;
		var pfad = pfadfile[0];
		var file = pfadfile[1];
		$(pfad).checked = true;
		$$('img.iconselect').removeClass('iconselect');
		if (scrollen != 1){
			$('markericontreeview').scrollTop = $(file).offsetTop-200;
		};
		$(file).addClass('iconselect');
	}else{
  var jsimg='components/com_gmap/assets/images/pin_rot.png';
		$$('img.iconselect').removeClass('iconselect');
		$('standard').addClass('iconselect');
	}
  document.imagelib.src=jsimg;
}
function setmarkericon (dir, file){
	$$('img.iconselect').removeClass('iconselect');
	$(file).addClass('iconselect');
  selectedmarkericondir =  dir;
  selectedmarkericonfile = file
var jsimg='../images/stories/com_gmap/'+ dir + '/' + file;
var newicon = dir + '/' + file ;
var seticon = myicon(dir + '/' + file);
	if (dir && file == 'standard'){
		newicon = 'standard' ;
		seticon = defaulticon();
     var jsimg=URIBase+'administrator/components/com_gmap/assets/images/pin_rot.png';
	}
  for(var i = 0; i < marker.length; i++){
		if(marker[i].gmselected == 'true'){
			marker[i].status = 'isedit';
			marker[i].markericon = newicon;
			marker[i].setOptions({
				icon : seticon,
			});
			refreshicontree (i,1)
		}
    }
    document.imagelib.src=jsimg;
}

function addmarkerevent(mid)
{
	google.maps.event.addListener(marker[mid], 'dragstart', function()
	{
		controlerMarker.clearMarkerSelection();
		marker[mid].gmselected = 'true';
		for(var i = 0; i < marker.length; i++){
			marker[i].setOpacity(0.4);
		}
		marker[mid].setOpacity(1.0);
		dummy_marker[mid].setVisible(false);
	});
	google.maps.event.addListener(marker[mid], 'dragend', function()
	{
		
		marker[mid].status = 'isedit';
		dummy_marker[mid].setIcon(mysystemicon('element_activ_no_save.png',15,26,7,7));
		dummy_marker[mid].setPosition(marker[mid].position);
		dummy_marker[mid].setVisible(true);
		markergeocoder(mid);
		markergetcontent(mid)
	});
	google.maps.event.addListener(marker[mid], 'click', function(event)
	{
		controlerMarker.clearMarkerSelection();
		showmarker();
		for(var i = 0; i < marker.length; i++){
			marker[i].setOpacity(0.4);
		}
		marker[mid].setOpacity(1.0);
		marker[mid].gmselected = 'true';
		initmarkertabelle();
		dummy_marker[mid].setVisible(true);
		markergetcontent(mid);
		if (marker[mid].text != '' && $('jform_showelement')[6].selected){ 	
			infowindow.setOptions({
				content : '<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+marker[mid].text + '</div>',
				pixelOffset:new google.maps.Size(0, 0) 
				});
				infowindow.open(map,marker[mid]);
		}else {
			infowindow.open(null);
		}
		return;

	});
	google.maps.event.addListener(marker[mid], 'rightclick', function(event)
	{
		for(var i = 0; i < marker.length; i++){
			marker[i].setOpacity(1.0);
		}

	});
}




function newmarker()
{
	showsubtab (0, 'marker');
	controlerMarker.clearMarkerSelection();
	var MarkerStart = map.getCenter();
	var newid = marker.length;
	marker[newid] = new google.maps.Marker(
	{
		map : map,
    animation : google.maps.Animation.DROP, 
	position : MarkerStart, 
    draggable : true, 
    status : 'isedit', 
    gmselected : 'true', 
    markernew : 'yes', 
    markerlat : '', 
    markerid : '', 
    markerlng : '', 
    markerort : '', 
    markerplz : '', 
    markericon : 'standard', 
    markertitel : Joomla.JText._('JS_MARKER_NEW'), 
    markerstrasse : '', 
    text : '',
	markermouseover : '',
	firstinfofenster: 'false', 
    icon : defaulticon(), 
	title: '',
	});
	dummy_marker[newid] = new google.maps.Marker(
	{
		position		: MarkerStart,
		draggable		: false,
		map				: map,
		icon		: mysystemicon('element_activ_no_save.png',15,26,7,7),
		visible: true,
	});
	if (selectedmarkericondir != ''){
    setmarkericon(selectedmarkericondir, selectedmarkericonfile);
  }else{
    setmarkericon('standard','standard');
  }
	addmarkerevent(newid);
	markergeocoder(newid);
}

function markergeocoder(mid)
{
	var lat = marker[mid].position.lat();
	var lng = marker[mid].position.lng();
	var latlng = new google.maps.LatLng(lat, lng);
	if(geocoder){
		geocoder.geocode({
			'latLng' : latlng
		}, 
		function(result, status){
			if(status == google.maps.GeocoderStatus.OK){
				if(result){
					addressfull = result[0].formatted_address;
					addresssplit = addressfull.split(",");
					count = (addresssplit.length);
					if(count === 3){
						streety = addresssplit[0];
						plzsplit = addresssplit[1].split(" ");
						plz = plzsplit[1];
						town = plzsplit[2]
					}else{
						streety = "";
						plzsplit = addresssplit[0].split(" ");
						plz = plzsplit[0];
						town = plzsplit[1]
					}
					marker[mid].markerstrasse = streety;
					marker[mid].markerplz = plz;
					marker[mid].markerort = town;
					markergetcontent(mid);
					var str = result[0].formatted_address
				}
			}else{
				marker[mid].markerstrasse = '';
				marker[mid].markerplz = '';
				marker[mid].markerort = '';
				markergetcontent(mid)
			}
		}
		)
	}
	marker[mid].markerlat = lat;
	marker[mid].markerlng = lng;
	markergetcontent(mid)
}
function setmarkeredit()
{
	for(var i = 0; i < marker.length; i++)
	{
		if(marker[i].markertitel != marker[i].oldmarkertitel || marker[i].markerort != marker[i].oldmarkerort || marker[i].markerstrasse != marker[i].oldmarkerstrasse || marker[i].markerplz != marker[i].oldmarkerplz || marker[i].title != marker[i].oldtitle || marker[i].markerbeschreibung != marker[i].oldmarkerbeschreibung || marker[i].markernew == 'yes')
		{
			if(marker[i].status != 'del')
			{
				marker[i].status = 'isedit'
			}
		}
	}
}

function movemarker(){
	var mid=controlerMarker.returnSelectedMarker();
			marker[mid].status = 'isedit';
			var address = $('jform_marker_address').value;
			geocoder.geocode({
				'address' : address
			},
			 function(results, status){
				if(status == google.maps.GeocoderStatus.OK){
					map.setCenter(results[0].geometry.location);
					marker[mid].setOptions({
						position : results[0].geometry.location
					});
					markergeocoder(mid);
					dummy_marker[mid].setPosition(marker[mid].position);
					dummy_marker[mid].setVisible(true);
					controlerMarker.returnSelectedMarker();
				}
			}
			)
}

function markergetcontent(mid)
{
	$('jform_marker_titel').value = marker[mid].markertitel;
	$('jform_marker_strasse').value = marker[mid].markerstrasse;
	$('jform_marker_plz').value = marker[mid].markerplz;
	$('jform_marker_ort').value = marker[mid].markerort;
	$('jform_marker_lat').value = marker[mid].markerlat;
	$('jform_marker_lng').value = marker[mid].markerlng;
	$('jform_marker_mouseover').value = marker[mid].title;
	document.getElementById('jform_marker_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML = marker[mid].text;
  refreshicontree (mid);
  radionSetCheckedValue('jform_marker_infowindow_open',marker[mid].firstinfofenster);
}


function setmarkertitle(){
	var i = controlerMarker.returnSelectedMarker();
	$('jform_marker_mouseover').value = $('jform_marker_titel').value + '\n' + $('jform_marker_plz').value + ' ' + $('jform_marker_ort').value;
	marker[i].title = $('jform_marker_mouseover').value;
	marker[i].status = 'isedit';
}

var controlerMarker ={
	clearMarkerSelection:function(option){
		this.setMarkerContent();
		for(var i = 0; i < marker.length; i++){
			marker[i].setOpacity(1.0);
			if (marker[i].status == 'isedit'){
				dummy_marker[i].setIcon(mysystemicon('element_passiv_no_save.png',15,26,7,7));
			}else{
				dummy_marker[i].setVisible(false);
				dummy_marker[i].setIcon(mysystemicon('element_activ.png',15,26,7,7));
			}
			  marker[i].gmselected = 'false';
			// marker[i].setOptions({draggable : true});
			  infowindow.open(null);
		}
	},	
	returnSelectedMarker: function(option){
		for(var i = 0; i < marker.length; i++){
		  if (marker[i].gmselected == 'true'){
			marker[i].setOpacity(1.0);
			dummy_marker[i].setIcon(mysystemicon('element_activ.png',15,26,7,7));
			if (marker[i].status == 'isedit'){
				dummy_marker[i].setIcon(mysystemicon('element_activ_no_save.png',15,26,7,7));
			}
			 return i; 
		  }};
		  return false;
	},
	setMarkerContent: function(option){
		var cid = this.returnSelectedMarker();
		if (cid === false) return;
		//marker[cid].status = 'isedit';
		marker[cid].markertitel = $('jform_marker_titel').value;
		marker[cid].markerstrasse = $('jform_marker_strasse').value;
		marker[cid].markerplz = $('jform_marker_plz').value;
		marker[cid].markerort = $('jform_marker_ort').value;
		marker[cid].markerlat = $('jform_marker_lat').value;
		marker[cid].markerlng = $('jform_marker_lng').value;
		marker[cid].title = $('jform_marker_mouseover').value;
		setmarkeredit();
	},
	setMarkerText: function(option){
		var cid = this.returnSelectedMarker();
		if (cid === false) return;
		marker[cid].status = 'isedit';
		marker[cid].text = document.getElementById('jform_marker_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML;
		marker[cid].text = returnFullImagePath(marker[cid].text);
		infowindow.setOptions({content : '<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+marker[cid].text + '</div>'});
		infowindow.open(map,marker[cid]);
	},	
	deleteMarkerText: function(option){
		var cid =this.returnSelectedMarker();
		if (cid === false) return;
		marker[cid].status = 'isedit';
		marker[cid].text = '';
		document.getElementById('jform_marker_beschreibung_ifr').contentWindow.document.getElementById('tinymce').innerHTML ='';
		infowindow.open(null);
	},
	setInfoWindowOpen: function(option){
		var cid = this.returnSelectedMarker();
		if (cid === false) return;
		main.InfoWindowOpen(cid,'marker', option);
		},
}

function markerdelete(index)
{
	removedata('gm_marker', marker[index].markerid);
	var markerdel = marker.splice(index, 1);
	initmarkertabelle()
}

function markershow(mid)
{
	markergetcontent(mid);
	controlerMarker.clearMarkerSelection();
	var markertext = marker[mid].text;
	map.setCenter(marker[mid].getPosition());
}

function saveallmarker(){
	var mcounter1 = 0;
	var mcounter2 = 0;
	controlerMarker.clearMarkerSelection();
	for(var i = 0; i < marker.length; i++){
		if(marker[i].status != 'del' && marker[i].status != 'standard'){
			mcounter1 += 1;
			}
		}
	if (mcounter1 != 0){	
		for(var i = 0; i < marker.length; i++){
			if(marker[i].status != 'del' && marker[i].status != 'standard'){
				mcounter2 += 1;
				if (mcounter1 > mcounter2){
					savemarker(i);
				}else if(mcounter1 == mcounter2){
					var last ='true';
					savemarker(i, last);
				}
			}
			cleartxt.markertxt();
			marker[i].setMap(null)
			dummy_marker[i].setMap(null);
		}
	}else{
	 main.SaveProgress(14);	
	}
}

function selectedmarkerdelete()
{
	var i = controlerMarker.returnSelectedMarker();
	if (i === false) return;
	marker[i].setMap(null);
	removedata('remove_marker', marker[i].markerid);
	marker[i].status = 'del';
	dummy_marker[i].setMap(null);
	cleartxt.markertxt();
	initmarkertabelle()
}

function markerdel(mid){
	marker[mid].setMap(null);
	dummy_marker[mid].setMap(null);
	removedata('remove_marker', marker[mid].markerid);
	marker[mid].status = 'del';
	cleartxt.markertxt();
	initmarkertabelle()
}
///////////////////////Cluster//////////////////////////
function addclusterevent (){
 google.maps.event.addListener(markercluster, "mouseover", function (event) {
		 var info = ('<p style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+Joomla.JText._('JS_MARKER_CLUSTER_INFO_WINDOW_PART_ONE'));
		 var cmarkers = event.getMarkers();
		 for(var i = 0; i < cmarkers.length; i++){ 
			if (i < '2'){
				info += '</br><strong>'+cmarkers[i].markertitel+'</strong>';
			}
		 }
		 if (cmarkers.length > '2'){
			 info +=Joomla.JText._('JS_MARKER_CLUSTER_INFO_WINDOW_PART_TWO');
		 }
		 
		 info += '</p>';
		infowindow.open(null);
		infowindow.setOptions(
				{
				content : info, 
				position : event.getCenter(),
				disableAutoPan:true, 
				pixelOffset:new google.maps.Size(0, -15)
				});
			if(radioGetCheckedValue('jform_marker_cluster_info_window') == 'true'){	
				infowindow.open(map);
			}
        });
 google.maps.event.addListener(markercluster, "mouseout", function (event) {
		infowindow.open(null);
		infowindow.setOptions({disableAutoPan:false, });
        });
 google.maps.event.addListener(markercluster, "click", function (event) {
		infowindow.open(null);
		infowindow.setOptions({disableAutoPan:false, });
        });
}
var controlerMarkerCluster = {
	setClusterActiv:function(option){
		if(radioGetCheckedValue('jform_marker_cluster_activ') == 'true' && $('jform_showelement')[7].selected == false){
			controlerMarker.clearMarkerSelection();
			this.setClusterIcon(map.folder_cluster_icon, map.cluster_icon);
			markercluster.setMaxZoom(19);
			markercluster.setGridSize(parseInt($('jform_marker_cluster_grid_size').value));
			markercluster.addMarkers(marker);
			addclusterevent ();
		}else{
			this.setClusterPassiv();
		}
	},
	setClusterPassiv:function(){
			markercluster.clearMarkers();
			for(var i = 0; i < marker.length; i++){
				marker[i].setMap(map);
			}
			google.maps.event.clearListeners(markercluster, 'mouseover');
	},
	setClusterGrid:function(){
		markercluster.setGridSize(parseInt($('jform_marker_cluster_grid_size').value));
		markercluster.repaint();
	},
	setClusterIcon:function(folder,image){
		if(image){
			var param = image.split("_");
			var styles = [[{
			  url: URIBase+'plugins/content/plg_content_gmap/assets/gm_cluster/'+folder+'/'+image,
			  width: param[0],
			  height: param[1],
			  textColor: '#'+param[2],
			  anchorText: [param[3],param[4]],//Y,X
			  textSize: 12
				}]];
			markercluster.setStyles(styles[0]);
			markercluster.repaint();
			map.folder_cluster_icon = folder;
			map.cluster_icon = image;
			}
	},
}
