
DROP TABLE IF EXISTS #__gm_circle;
CREATE TABLE `#__gm_circle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_map` int(3) NOT NULL,
  `circle_position1_lat` varchar(20) NOT NULL,
  `circle_position1_lng` varchar(20) NOT NULL,
  `circle_radius` int(20) NOT NULL,
  `circle_farbe_linie` varchar(10) NOT NULL,
  `circle_linie_breite` int(2) NOT NULL,
  `circle_transparent_linie` varchar(5) NOT NULL,
  `circle_farbe_fuellung` varchar(10) NOT NULL,
  `circle_transparent_fuellung` varchar(5) NOT NULL,
  `circle_parameter` text NOT NULL,
  `circle_beschreibung` text NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_config;
CREATE TABLE `#__gm_config` (
  `id` int(5) NOT NULL DEFAULT '1',
  `conf_map_breite` varchar(5) NOT NULL,
  `conf_map_hoehe` varchar(5) NOT NULL,
  `conf_start_zoom` varchar(5) NOT NULL,
  `conf_center_lat` varchar(20) NOT NULL,
  `conf_center_lng` varchar(20) NOT NULL,
  `conf_parameter` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) DEFAULT CHARSET=utf8;

INSERT INTO `#__gm_config` VALUES (1, '600', '600', '5', '52.05688697392451', '10.249298095703118', '');

DROP TABLE IF EXISTS #__gm_lang;
CREATE TABLE IF NOT EXISTS `#__gm_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_title` varchar(80) NOT NULL,
  `lang_short` varchar(5) NOT NULL,
  `lang_button_title` varchar(100) NOT NULL,
  `lang_slider_map_view` varchar(100) NOT NULL,
  `lang_map_view_roadmap` varchar(100) NOT NULL,
  `lang_map_view_terrain` varchar(100) NOT NULL,
  `lang_map_view_satellite` varchar(100) NOT NULL,
  `lang_map_view_hybrid` varchar(100) NOT NULL,
  `lang_slider_layer` varchar(100) NOT NULL,
  `lang_layer_bike` varchar(100) NOT NULL,
  `lang_layer_traffic` varchar(100) NOT NULL,
  `lang_layer_transit` varchar(100) NOT NULL,
  `lang_layer_weather` varchar(100) NOT NULL,
  `lang_layer_streetview` varchar(100) NOT NULL,
  `lang_slider_panoramio` varchar(100) NOT NULL,
  `lang_panoramio_panoramio` varchar(100) NOT NULL,
  KEY `id` (`id`)
) DEFAULT CHARSET=utf8 ;

INSERT INTO `#__gm_lang` (`id`, `lang_title`, `lang_short`, `lang_button_title`, `lang_slider_map_view`, `lang_map_view_roadmap`, `lang_map_view_terrain`, `lang_map_view_satellite`, `lang_map_view_hybrid`, `lang_slider_layer`, `lang_layer_bike`, `lang_layer_traffic`, `lang_layer_transit`, `lang_layer_weather`, `lang_layer_streetview`, `lang_slider_panoramio`, `lang_panoramio_panoramio`) VALUES
(1, 'German', 'de', 'Einstellungen', 'Karten Ansicht', 'Straßenkarte', 'Geländekarte', 'Satellit', 'Satellit & Beschriftung', 'Ebenen', 'Radwege', 'Straßenverkehr', 'Öffentliche Verkehrsmittel', 'Wetter', 'Street View', 'Panoramio', 'Panoramio'),
(2, 'English', 'en', 'Settings', 'Maps View', 'Road map', 'Terrain map', 'Satellite', 'Satellite & Marking', 'Layers', 'Bike paths', 'Road Traffic', 'Public transport', 'Weather', 'Streetview', 'Panoramio', 'Panoramio'),
(3, 'French', 'fr', 'Réglages', 'Cartes vue', 'Carte routière', 'Carte du terrain', 'Satellite', 'Satellite & Marquage', 'Niveaux', 'Les pistes cyclables', 'Circulation routière', 'Transport en commun', 'Météo', 'Street View', 'Panoramio', 'Panoramio');

DROP TABLE IF EXISTS #__gm_line;
CREATE TABLE `#__gm_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_map` int(3) NOT NULL,
  `line_titel` varchar(100) NOT NULL,
  `line_breite` int(2) NOT NULL,
  `line_farbe` varchar(10) NOT NULL,
  `line_transparent` varchar(3) NOT NULL,
  `line_punkte` text NOT NULL,
  `line_parameter` text NOT NULL,
  `line_beschreibung` text NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_map;
CREATE TABLE `#__gm_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_titel` varchar(255) NOT NULL,
  `map_beschreibung` text NOT NULL,
  `map_center_lat` varchar(30) NOT NULL,
  `map_center_lng` varchar(30) NOT NULL,
  `map_zoom` varchar(3) NOT NULL,
  `map_parameter` text NOT NULL,
  `street_view_parameter` text NOT NULL,
  `panoramio_parameter` text NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_marker;
CREATE TABLE `#__gm_marker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_map` int(3) NOT NULL,
  `marker_titel` varchar(100) NOT NULL,
  `marker_strasse` varchar(150) NOT NULL,
  `marker_plz` varchar(6) NOT NULL,
  `marker_ort` varchar(50) NOT NULL,
  `marker_beschreibung` text NOT NULL,
  `marker_icon` varchar(60) NOT NULL,
  `marker_lng` varchar(30) NOT NULL,
  `marker_lat` varchar(30) NOT NULL,
  `marker_parameter` text NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_rectangle;
CREATE TABLE `#__gm_rectangle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_map` int(3) NOT NULL,
  `rectangle_position1_lat` varchar(20) NOT NULL,
  `rectangle_position1_lng` varchar(20) NOT NULL,
  `rectangle_position2_lat` varchar(20) NOT NULL,
  `rectangle_position2_lng` varchar(20) NOT NULL,
  `rectangle_farbe_linie` varchar(10) NOT NULL,
  `rectangle_linie_breite` int(2) NOT NULL,
  `rectangle_transparent_linie` varchar(5) NOT NULL,
  `rectangle_farbe_fuellung` varchar(10) NOT NULL,
  `rectangle_transparent_fuellung` varchar(5) NOT NULL,
  `rectangle_parameter` text NOT NULL,
  `rectangle_beschreibung` text NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS #__gm_polygon;
CREATE TABLE `#__gm_polygon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_map` int(10) NOT NULL,
  `polygon_titel` varchar(100) NOT NULL,
  `polygon_color_line` varchar(10) NOT NULL,
  `polygon_width_line` varchar(2) NOT NULL,
  `polygon_transparent_line` varchar(5) NOT NULL,
  `polygon_color_fill` varchar(10) NOT NULL,
  `polygon_transparent_fill` varchar(5) NOT NULL,
  `polygon_path` text NOT NULL,
  `polygon_parameter` text NOT NULL,
  `polygon_beschreibung` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_text;
CREATE TABLE `#__gm_text` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_map` int(5) NOT NULL,
  `text_text` text NOT NULL,
  `text_lat` varchar(20) NOT NULL,
  `text_lng` varchar(20) NOT NULL,
  `text_parameter` text NOT NULL,
  KEY `id` (`id`)
) DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS #__gm_kml;
CREATE TABLE IF NOT EXISTS `#__gm_kml` (
	`id` int(5) NOT NULL AUTO_INCREMENT,
	`kml_title` varchar(100) NOT NULL,
	`kml_pfad` varchar(200) NOT NULL,
	`kml_beschreibung` text NOT NULL,
	`kml_parameter` text NOT NULL,
	KEY `id` (`id`)
)  DEFAULT CHARSET=utf8;

INSERT INTO `#__gm_kml` (`id`, `kml_title`, `kml_pfad`, `kml_beschreibung`, `kml_parameter`) VALUES
(1, 'Sample KML', 'http://www.joomla.de.com/kml/sample.kml', 'Beispiel Text für ein Info Fenster', '');