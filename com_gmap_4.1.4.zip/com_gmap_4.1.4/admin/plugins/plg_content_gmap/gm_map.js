// JavaScript Document
var mapsetup =new Array();
function gm_element(ele){
var my_gm_element = document.getElementById(ele);
return my_gm_element;
}

function myicon(icon){
if (icon != 'standard'){
  var geticon = new google.maps.MarkerImage(URIBase+'images/stories/com_gmap/' + icon);
  }
if (icon == 'standard'){
  var geticon = new google.maps.MarkerImage(URIBase+'components/com_gmap/assets/images/pin_rot.png');
  }
  return geticon;
  }

function gm_initialize() {
	
	var lang ='';
	for(var i = 0; i< karten.length; i++) {
		var mapid = (karten[i].karte);
		//init all maps
		getdata('gm_maps','form_maps', 'raw', 'getallmaps',mapid);
		mapsetup[mapid] = 'off';
		bikelayer[mapid] = new google.maps.BicyclingLayer();
		trafficlayer[mapid] = new google.maps.TrafficLayer();
		transitlayer[mapid] = new google.maps.TransitLayer();
		weatherlayer[mapid] = new google.maps.weather.WeatherLayer();
		elevator[mapid] = new google.maps.ElevationService();
		markercluster[mapid] = new MarkerClusterer(map[mapid]);
			weatherlayer[mapid].setOptions({
				temperatureUnits: google.maps.weather.TemperatureUnit[map[mapid].map_weather_temperature_unit],
				windSpeedUnits: google.maps.weather.WindSpeedUnit[map[mapid].map_weather_windspeed_unit]
			});
		streetviewlayer[mapid] = map[mapid].getStreetView();
		panoramiolayer[mapid] = new google.maps.panoramio.PanoramioLayer ();
			panoramiolayer[mapid].setTag(map[mapid].panoramio_tag);
			panoramiolayer[mapid].setUserId(map[mapid].panoramio_userid);
			if (map[mapid].street_view_center_lat != ''){	
				  var mapcenter = new google.maps.LatLng(map[mapid].street_view_center_lat,map[mapid].street_view_center_lng
			);
				streetviewlayer[mapid].setPosition(mapcenter);
				streetviewlayer[mapid].setPov({
								heading:parseFloat(map[mapid].street_view_heading),
								zoom:	parseInt(map[mapid].street_view_zoom),
								pitch:	parseFloat(map[mapid].street_view_pitch)
								});
		}
				//init all markers
			getdata('gm_markers','form_markers', 'raw', 'getallmarker',mapid);
			//init all circle					
			getdata('gm_circles','form_circles', 'raw', 'getallcircle',mapid);
			//init all rectangles
			getdata('gm_rectangles','form_rectangles', 'raw', 'getallrectangle',mapid);
			//init all line
			getdata('gm_lines','form_lines', 'raw', 'getallline',mapid);
			//init all polygon
			getdata('gm_polygon','form_polygon', 'raw', 'getallpolygon',mapid);
			//init all text 
			getdata('gm_texte','form_texte', 'raw', 'getalltexte',mapid);
			//init all KML
			if (map[mapid].kml_files != ''){
				getkml('gm_kml', 'form_kml', 'raw',mapid);//View, Layout, Format
			}
			
	}
}

function maploadevent(mapid){
		google.maps.event.addListener(map[mapid], 'tilesloaded', function() {
			setmapsetupbutton(mapid);
			setbuttonoption(mapid);
			mapsetupviewoff(mapid);
			setmapview.maptyp(map[mapid].mapTypeId, mapid);
			setmapview.bike(mapid);
			setmapview.traffic(mapid);
			setmapview.transit(mapid);
			setmapview.weather(mapid);
			 if( map[mapid].street_view_activ == 'true'){
				streetviewlayer[mapid].setOptions({visible:true});
			 }
			setmapview.panoramio(mapid);
			var logoControlDiv = document.createElement('DIV');
			var logoControl = new MyLogoControl(logoControlDiv);
				logoControlDiv.index = 1; // used for ordering
				map[mapid].controls[google.maps.ControlPosition.LEFT_BOTTOM].push(logoControlDiv);
		});
}

function MyLogoControl(controlDiv) {
    controlDiv.style.padding = '5px';
	var logo = document.createElement('DIV');
	var logotext = '<a id="logo_button" title="Powered by joomla-24.de" target="new" href="http://www.joomla-24.de">';
		logotext+='<img src='+URIBase+'components/com_gmap/assets/images/joomla-icon.png /></a>';
	logo.innerHTML = logotext;
    logo.style.cursor = 'pointer';
    controlDiv.appendChild(logo);
}


function addmarkerevent (mapid, mid){
	google.maps.event.addListener(marker[mapid][mid], 'click', function() {
		infowindow[mapid].setMap(null);
		jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	  	jQuery( "#map_elevation_close"+mapid ).css( "visibility", "hidden"); 
		infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+marker[mapid][mid].markerbeschreibung + '</div>',
			position	:marker[mapid][mid].position,
		});
		if (marker[mapid][mid].markerbeschreibung != '') {
			infowindow[mapid].open(map[mapid],marker[mapid][mid]);
		}
	});
	if (marker[mapid][mid].firstinfofenster == 'checked') {
		infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+marker[mapid][mid].markerbeschreibung + '</div>',
			position	:marker[mapid][mid].position,
		});
		infowindow[mapid].open(map[mapid],marker[mapid][mid]);
	}
	google.maps.event.addListener(marker[mapid][mid], 'mouseover', function() {
		marker[mapid][mid].setOpacity(1.0);
		});
	google.maps.event.addListener(marker[mapid][mid], 'mouseout', function() {
		marker[mapid][mid].setOpacity(0.85);
		});
		
}

function  initMarkerCluster(mapid){
	if (map[mapid].marker_cluster_activ == 'true'){
		var param = map[mapid].map_cluster_icon.split("_");
			var styles = [[{
			  url: URIBase+'plugins/content/plg_content_gmap/assets/gm_cluster/'+map[mapid].map_folder_cluster_icon+'/'+map[mapid].map_cluster_icon,
			  width: param[0],
			  height: param[1],
			  textColor: '#'+param[2],
			  anchorText: [param[3],param[4]],//Y,X
			  textSize: 12
				}]];
		markercluster[mapid].setStyles(styles[0]);
		markercluster[mapid].setMaxZoom(15);
		markercluster[mapid].setGridSize(parseInt(map[mapid].marker_cluster_grid_size));
		markercluster[mapid].addMarkers(marker[mapid]);
		addclusterevent (mapid);
	}
}
function addclusterevent (mapid){
 google.maps.event.addListener(markercluster[mapid], "mouseover", function (event) {
		 var info = ('<p style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+Joomla.JText._('JS_MARKER_CLUSTER_INFO_WINDOW_PART_ONE'));
		 var cmarkers = event.getMarkers();
		 for(var i = 0; i < cmarkers.length; i++){ 
			if (i < '2'){
				info += '</br><strong>'+cmarkers[i].markertitel+'</strong>';
			}
		 }
		 if (cmarkers.length > '2'){
			 info +=Joomla.JText._('JS_MARKER_CLUSTER_INFO_WINDOW_PART_TWO');
		 }
		 
		 info += '</p>';
		infowindow[mapid].open(null);
		infowindow[mapid].setOptions(
				{
				content : info,
				disableAutoPan:true, 
				position : event.getCenter(),
				pixelOffset:new google.maps.Size(0,-15)
				});
				infowindow[mapid].open(map[mapid]);
        });
 google.maps.event.addListener(markercluster[mapid], "mouseout", function (event) {
		infowindow[mapid].open(null);
		infowindow[mapid].setOptions({pixelOffset:new google.maps.Size(0,0),disableAutoPan:false, });
        });
 google.maps.event.addListener(markercluster[mapid], "click", function (event) {
		infowindow[mapid].open(null);
		infowindow[mapid].setOptions({pixelOffset:new google.maps.Size(0,0),disableAutoPan:false, });
        });
}

function addcircleevent (mapid, cid){
	google.maps.event.addListener(circle[mapid][cid], 'click', function(event) {
		jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	  	jQuery( "#map_elevation_close"+mapid ).css( "visibility", "hidden");
		infowindow[mapid].open(null); 
		if (circle[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+circle[mapid][cid].circlebeschreibung+ '</div>',
				position	:event.latLng,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+circle[mapid][cid].circlebeschreibung+ '</div>',
				position	:circle[mapid][cid].positinfowindow,
			});
		}
		if (circle[mapid][cid].circlebeschreibung != '') {
			infowindow[mapid].open(map[mapid]);
		}
	});
	if (circle[mapid][cid].firstinfofenster == 'checked') {
		if (circle[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+circle[mapid][cid].circlebeschreibung+ '</div>',
				position	:circle[mapid][cid].center,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+circle[mapid][cid].circlebeschreibung+ '</div>',
				position	:circle[mapid][cid].positinfowindow,
			});
			
		}
		infowindow[mapid].open(map[mapid]);
	}
}
function addrectangleevent (mapid, cid){
	google.maps.event.addListener(rectangle[mapid][cid], 'click', function(event) {
		jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	  	jQuery( "#map_elevation_close"+mapid ).css( "visibility", "hidden"); 
		infowindow[mapid].open(null);
		if (rectangle[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+rectangle[mapid][cid].rectanglebeschreibung+ '</div>',
				position	:event.latLng,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+rectangle[mapid][cid].rectanglebeschreibung+ '</div>',
				position	:rectangle[mapid][cid].positinfowindow,
			});
		}
		if (rectangle[mapid][cid].rectanglebeschreibung != '') {
			infowindow[mapid].open(map[mapid]);
		}
	});
	if (rectangle[mapid][cid].firstinfofenster == 'checked') {
		if (rectangle[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+rectangle[mapid][cid].rectanglebeschreibung+ '</div>',
				position	:circle[mapid][cid].center,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+rectangle[mapid][cid].rectanglebeschreibung+ '</div>',
				position	:rectangle[mapid][cid].positinfowindow,
			});
			
		}
		infowindow[mapid].open(map[mapid]);
	}
}
function addlineevent (mapid, cid){
	line[mapid][cid].getLength = getlinelength;
	google.maps.event.addListener(dummy_line[mapid][cid], 'click', function(event) {
		infowindow[mapid].open(null);
		if (line[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+line[mapid][cid].linebeschreibung+ '</div>',
				position	:event.latLng,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+line[mapid][cid].linebeschreibung+ '</div>',
				position	:line[mapid][cid].positinfowindow,
			});
		}
		if (line[mapid][cid].linebeschreibung != '') {
			infowindow[mapid].open(map[mapid]);
		}
		setlinechart(mapid,cid);
	});
	if (line[mapid][cid].firstinfofenster == 'checked') {
		if (line[mapid][cid].positinfowindow == 'false'){
			var point= line[mapid][cid].getPath().getArray();
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+line[mapid][cid].linebeschreibung+ '</div>',
				position	:point[0],
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+line[mapid][cid].linebeschreibung+ '</div>',
				position	:line[mapid][cid].positinfowindow,
			});
			
		}
		infowindow[mapid].open(map[mapid]);
	}
}
function addpolygonevent (mapid, cid){
	google.maps.event.addListener(polygon[mapid][cid], 'click', function(event) {
		jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	  	jQuery( "#map_elevation_close"+mapid ).css( "visibility", "hidden"); 

		infowindow[mapid].open(null);
		if (polygon[mapid][cid].positinfowindow == 'false'){
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+polygon[mapid][cid].polygonbeschreibung+ '</div>',
				position	:event.latLng,
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+polygon[mapid][cid].polygonbeschreibung+ '</div>',
				position	:polygon[mapid][cid].positinfowindow,
			});
		}
		if (polygon[mapid][cid].polygonbeschreibung != '') {
			infowindow[mapid].open(map[mapid]);
		}
	});
	if (polygon[mapid][cid].firstinfofenster == 'checked') {
		if (polygon[mapid][cid].positinfowindow == 'false'){
			var point= polygon[mapid][cid].getPath().getArray();
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+polygon[mapid][cid].polygonbeschreibung+ '</div>',
				position	:point[0],
			});
		}else{
			infowindow[mapid].setOptions({
			content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+polygon[mapid][cid].polygonbeschreibung+ '</div>',
				position	:polygon[mapid][cid].positinfowindow,
			});
			
		}
		infowindow[mapid].open(map[mapid]);
	}
}
function addkmlevent (mapid, kmlid){
 google.maps.event.addListener(kmllayer[mapid][kmlid], "click", function (event) {
		if (kmllayer[mapid][kmlid].kml_beschreibung != ''){
			kmllayer[mapid][kmlid].setOptions({suppressInfoWindows: true});
			infowindow[mapid].open(null);
			infowindow[mapid].setOptions(
					{
					content : kmllayer[mapid][kmlid].kml_beschreibung, 
					position : event.latLng,
					});
			infowindow[mapid].open(map[mapid]);		
		}
        });
}
function getlinelength(){
	var factor = 1000
	var wert = google.maps.geometry.spherical.computeLength(this.getPath());
	var	erg1 = Math.round((wert)/parseFloat(factor)*100)/100;
	var erg2 = Math.round((wert/1000)*100)/100;
	return erg2;	
}

function setlinechart(mapid,cid) {
	function plotElevation(results, status, thisline) {
	  if (status != google.maps.ElevationStatus.OK) {
		return;
	  }
		if (line[mapid][cid].chartunits == 'SI'){
			var distanz = line[mapid][cid].getLength();
			titley = Joomla.JText._('JS_CHART_TITLE_AXE_Y_HEIGHT_SI');
			titlex = Joomla.JText._('JS_CHART_TITLE_AXE_X_DISTANZ_SI')
		}else{
			var distanz = Math.round (line[mapid][cid].getLength()/parseFloat(1.609)*100)/100;
			titley = Joomla.JText._('JS_CHART_TITLE_AXE_Y_HEIGHT_ANGLO');
			titlex = Joomla.JText._('JS_CHART_TITLE_AXE_X_DISTANZ_ANGLO')
		}
	  var elevations = results;
	  var data = new google.visualization.DataTable();
	  data.addColumn('string', 'Sample');
	  data.addColumn('number', 'Höhe');
	  for (var i = 0; i < results.length; i++) {
		  if (line[mapid][cid].chartunits == 'SI'){
		 	data.addRow(['', Math.round((parseInt(elevations[i].elevation))/parseFloat(1)*100)/100]);
		  }else{
			data.addRow(['', Math.round((parseInt(elevations[i].elevation))/parseFloat(0.9144)*100)/100]);  
		  }
	  }
	  jQuery( "#map_elevation"+mapid ).slideDown( "slow");
	  jQuery( "#map_elevation_close"+mapid ).css( "visibility", "visible"); 
	  chart[mapid].draw(data, {
		height: 100,
		title: Joomla.JText._('JS_CHART_TITLE'),
		legend: { position: "none" },
		titleY: titley,
		titleX: titlex + distanz
	  });
	}

	//jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	if(line[mapid][cid].chartonoff == 'true'){
		chart[mapid] = new google.visualization.LineChart(document.getElementById('map_elevation'+mapid));
		var pathRequest = {
						'path': line[mapid][cid].getPath().getArray(),
						'samples': 500
						}
		elevator[mapid].getElevationAlongPath(pathRequest, plotElevation);	
	}else{
		jQuery( "#map_elevation"+mapid ).slideUp( "slow");
	  	jQuery( "#map_elevation_close"+mapid ).css( "visibility", "hidden"); 
	
	}

}


function setmapsetupbutton(mapid){
	var mycustom = document.createElement('div');
	mycustom.setAttribute("id", "setup_map_button"+mapid);
	mycustom.setAttribute("class", "setup_map_button");
	mycustom.innerHTML =map[mapid].setup_button_html;
	map[mapid].controls[google.maps.ControlPosition.TOP_RIGHT].push(mycustom);
	loadaccordion();
	if (map[mapid].map_setup_button == 'none'){ 
		jQuery('#setup_map_button'+mapid).hide();
	}
}


function togglemapsetupview (mapid) {
		var check = (mapsetup[mapid] == 'on') ?
			mapsetupviewoff(mapid) :
			mapsetupviewon(mapid);
}
function mapsetupviewon (mapid){
	jQuery('#setup_button_box_'+mapid).show();
		mapsetup[mapid] = 'on'	;
}
function mapsetupviewoff (mapid){
		jQuery('#setup_button_box_'+mapid).hide();
			mapsetup[mapid] = 'off'	;
}


var setmapview ={
	maptyp		: function(button, mapid){
					var listitem = new Array();
					listitem =	jQuery('#button_list_1 li.list_item_on');	
					listitem.removeClass('list_item_on').addClass('list_item_off'); 
					jQuery('#map_view_item_'+button+'_'+mapid).removeClass('list_item_off').addClass('list_item_on')
					map[mapid].setOptions({mapTypeId:button});
	},
	bike		: function(mapid){
			  		var check = map[mapid].map_bike_layer == 'map' ?
					 [
					 bikelayer[mapid].setMap(map[mapid]),
					 jQuery('#map_layer_bike_'+mapid).removeClass('list_item_off').addClass('list_item_on'),
					map[mapid].map_bike_layer = 'null'
					 ]
					 :
					 [
					 bikelayer[mapid].setMap(null),
					 jQuery('#map_layer_bike_'+mapid).removeClass('list_item_on').addClass('list_item_off'),
					 map[mapid].map_bike_layer = 'map'
					 ]
		
	},
	traffic			: function(mapid){
			  		var check = map[mapid].map_traffic_layer == 'map' ?
					 [
					 trafficlayer[mapid].setMap(map[mapid]),
					 jQuery('#map_layer_traffic_'+mapid).removeClass('list_item_off').addClass('list_item_on'),
					 map[mapid].map_traffic_layer = 'null'
					 ]
					 :
					 [
					 trafficlayer[mapid].setMap(null),
					 jQuery('#map_layer_traffic_'+mapid).removeClass('list_item_on').addClass('list_item_off'),
					 map[mapid].map_traffic_layer = 'map'
					 ]
		
	},
	transit			: function(mapid){
			  		var check = map[mapid].map_transit_layer == 'map' ?
					 [
					 transitlayer[mapid].setMap(map[mapid]),
					 jQuery('#map_layer_transit_'+mapid).removeClass('list_item_off').addClass('list_item_on'),
					 map[mapid].map_transit_layer = 'null'
					 ]
					 :
					 [
					 transitlayer[mapid].setMap(null),
					 jQuery('#map_layer_transit_'+mapid).removeClass('list_item_on').addClass('list_item_off'),
					 map[mapid].map_transit_layer = 'map'
					 ]
		
	},
	weather			: function(mapid){
			  		var check = map[mapid].map_weather_layer == 'map' ?
					 [
					 weatherlayer[mapid].setMap(map[mapid]),
					 jQuery('#map_layer_weather_'+mapid).removeClass('list_item_off').addClass('list_item_on'),
					 map[mapid].map_weather_layer = 'null'
					 ]
					 :
					 [
					 weatherlayer[mapid].setMap(null),
					 jQuery('#map_layer_weather_'+mapid).removeClass('list_item_on').addClass('list_item_off'),
					 map[mapid].map_weather_layer = 'map'
					 ]
		
	},
	streetview		: function(mapid){
						streetviewlayer[mapid].setOptions({visible:true});
	},
	panoramio		: function(mapid){
					  if( map[mapid].map_panoramio_layer == 'map'){
						 panoramiolayer[mapid].setMap(map[mapid]);
						 jQuery('#map_layer_panoramio_'+mapid).removeClass('list_item_off').addClass('list_item_on');
						 map[mapid].map_panoramio_layer = 'null';
					  }
					  else{
						panoramiolayer[mapid].setMap(null);
						jQuery('#map_layer_panoramio_'+mapid).removeClass('list_item_on').addClass('list_item_off');
						map[mapid].map_panoramio_layer = 'map';
						  }
						google.maps.event.clearListeners(map[mapid], 'tilesloaded');
	}

}

function setbuttonoption (mapid) {
	
	var check = (map[mapid].map_typ_control_button =='block') ?
		jQuery('#accordion_toggler_1_'+mapid).css('display', 'block'):
		jQuery('#accordion_toggler_1_'+mapid).css('display', 'none');

	var check = (map[mapid].map_layer_button =='block') ?
		jQuery('#accordion_toggler_2_'+mapid).css('display', 'block'):
		jQuery('#accordion_toggler_2_'+mapid).css('display', 'none');
	if (map[mapid].street_view_center_lat !=''){
			jQuery('#map_layer_streetview_'+mapid).removeClass('button_view_off').addClass('list_item_off');
	}else{
		jQuery('#map_layer_streetview_'+mapid).addClass('button_view_off');
	}
	var check = (map[mapid].map_panoramio_button =='block') ?
		jQuery('#accordion_toggler_3_'+mapid).css('display', 'block'):
		jQuery('#accordion_toggler_3_'+mapid).css('display', 'none');

}


function custominfo (mapid, mid) {
	 var breite = 'min';
	 var hoehe = 'auto';
	var custom = new ToolTip(breite, hoehe, map[mapid], marker[mapid][mid].position, marker[mapid][mid].markerbeschreibung, mid);
}



//////////////////////
 
ToolTip.prototype = new google.maps.OverlayView();

function ToolTip(breite, hoehe, map, latlng, text, tid) {
 
    // Now initialize all properties.
   	this.versatz_x_ = 0;
	this.versatz_y_ = 0;
	this.latlng_ = latlng;
    this.map_ = map;
	this.breite_ = breite;
	this.hoehe_ = hoehe;
 	//this.html_ = html;
	this.html_ = text;
	this.textid= tid;
    this.div_ = null;
    // Explicitly call setMap on this overlay
    this.setMap(map);
  }
 
  ToolTip.prototype.onAdd = function() {
    // Create the DIV and set some basic attributes.
    var div = document.createElement('DIV');
	div.innerHTML = this.html_;
	div.setAttribute("id", "text");
	div.setAttribute("onclick", "");
    div.style.position = "absolute";
    // Set the overlay's div_ property to this DIV
    this.div_ = div;
    // We add an overlay to a map via one of the map's panes.
    // We'll add this overlay to the overlayImage pane.
    var panes = this.getPanes();
    panes.overlayImage.appendChild(div);
  }
 
  ToolTip.prototype.draw = function() {
    var overlayProjection = this.getProjection();
   var pixPosition = this.getProjection().fromLatLngToDivPixel(this.latlng_);
  if (!pixPosition) return;
    // Resize the image's DIV to fit the indicated dimensions.
    var div = this.div_;
    div.style.left =(pixPosition.x + this.versatz_x_ ) + "px";
    div.style.top = (pixPosition.y + this.versatz_y_) + "px";
    div.style.width =this.breite_ ;
    div.style.height = this.hoehe_ + 'px';
 
  }
 
  ToolTip.prototype.onRemove = function() {
    this.div_.parentNode.removeChild(this.div_);
    this.div_ = null;
  } 

//
// Verschachteltes Mootools-Accordion
// Nested Mootools Accordion
// 
// von / by Bogdan Günther
// http://www.medianotions.de
//

function loadaccordion() {
	jQuery("div.accordion").accordion({
    heightStyle: "content",
    collapsible: true,
    active: false
});
}	
var gmapAction ={
	MapZoom		: function(mapid,zoom){
					map[mapid].setOptions({zoom:zoom});
					if (map[mapid].marker_cluster_activ == 'true'){
						markercluster[mapid].repaint();
					}
	},
	MapMove		: function(mapid,lat,lng){
					map[mapid].setOptions({center: new google.maps.LatLng(lat,lng)});
					if (map[mapid].marker_cluster_activ == 'true'){
						markercluster[mapid].repaint();
					}
	},
	MapMoveAndZoom		: function(mapid,zoom,lat,lng){
					map[mapid].setOptions({
						zoom:zoom,
						center: new google.maps.LatLng(lat,lng),
						});
					if (map[mapid].marker_cluster_activ == 'true'){
						markercluster[mapid].repaint();
					}
	},
}

function mod_search_refresh(mapid) {
	var url = location.href
	var name = 'mid'
	name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
	var regexS = "[\\?&]"+name+"=([^&#]*)";
	var regex = new RegExp( regexS );
	var mid = regex.exec( url );
	if(!mid) {
		return ;
	 }
    mid = mid[1];
	for(var i = 0; i < marker[mapid].length; i++){
		if (marker[mapid][i].id == mid){
			infowindow[mapid].setMap(null);
			infowindow[mapid].setOptions({
				content		:'<div style="font-family: Arial,Helvetica,sans-serif;line-height: normal;color: #000000; padding: 0px; margin: 0px;">'+marker[mapid][i].markerbeschreibung + '</div>',
				position	:marker[mapid][i].position,
			});
			map[mapid].setCenter(marker[mapid][i].position);
				if (marker[mapid][i].markerbeschreibung != '') {
					infowindow[mapid].open(map[mapid],marker[mapid][i]);
				}
		}
  	}

}
google.maps.event.addDomListener(window, 'load', gm_initialize);