<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

//-- No direct access
defined('_JEXEC') or die('Restricted access');

class plgContentplg_content_gmap extends JPlugin
{ 
	protected $autoloadLanguage = true;
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadJSLanguageKeys('/plugins/content/plg_content_gmap/gm_map.js');
		
		
	}

protected function loadJSLanguageKeys($jsFile)
{
    if (isset($jsFile))
    {
        $jsFile = JPATH_ROOT. $jsFile;
    }
    else
    {
        return false;
    }

    if ($jsContents = file_get_contents($jsFile))
    {
        $languageKeys = array();
        preg_match_all('/Joomla\.JText\._\(\'(.*?)\'\)\)?/', $jsContents, $languageKeys);
        $languageKeys = $languageKeys[1];

        foreach ($languageKeys as $lkey)
        {
            JText::script($lkey);
        }
    }
}

public function onContentPrepare($context, &$row, &$params, $page = 0)
{	

	
	$document = JFactory::getDocument();
	$db			= JFactory::getDBO();
	//Karte identifizieren		
	$regex1 = '/{gm.+?}/';
	preg_match_all ($regex1, $row->text, $karten,PREG_SET_ORDER);
	if (count($karten) > 0){
		$js1 = 'var karten = [';
		for ($i=0, $n=count($karten); $i < $n; $i++){
			$karte = trim($karten[$i][0], "\{gm"); 
			$id = trim($karte, "\}");
			$js1 .= '{';
			$js1 .= '\'karte\':'.$id;
			$js1 .= '},';
		};
	
      	$js1 .= '];';
	$document->addScriptDeclaration( $js1 );
		$query = "SELECT * FROM #__gm_map WHERE id= '$id' ORDER BY id ASC";
		$db->setQuery( $query );
		$row2 = $db->loadObject();
		$map_parameter = array();
		$teile = explode(",", $row2->map_parameter);
			for ($i=0, $n=count( $teile ); $i < $n; $i++){
				$parameter = explode(":", $teile[$i]);
				$map_parameter[$parameter[0]] = $parameter[1];
			}
		if ($map_parameter['map_language'] == 'auto'){
			$lang = JFactory::getLanguage();
			$teile = explode("-", $lang->getTag());
			$document->addScript('https://maps.googleapis.com/maps/api/js?v=3.16&sensor=false&language='.$teile[0].'&libraries=weather,drawing,geometry,panoramio');
		}
		if ($map_parameter['map_language'] == '0' and $map_parameter['custom_map_language'] != '' ){
			$document->addScript('https://maps.googleapis.com/maps/api/js?v=3.16&sensor=false&language='.$map_parameter['custom_map_language'].'&libraries=weather,drawing,geometry,panoramio');
		}
		if ($map_parameter['map_language'] != 'auto' and $map_parameter['map_language'] != '0' ){
			$document->addScript('https://maps.googleapis.com/maps/api/js?v=3.16&sensor=false&language='.$map_parameter['map_language'].'&libraries=weather,drawing,geometry,panoramio');
		}
		if ($map_parameter['map_language'] == '0' and $map_parameter['custom_map_language'] == '' ){
			$lang = JFactory::getLanguage();
			$teile = explode("-", $lang->getTag());
			$document->addScript('https://maps.googleapis.com/maps/api/js?v=3.16&sensor=false&language='.$teile[0].'&libraries=weather,drawing,geometry,panoramio');
		}
		JHTML::_('behavior.core', true);
		JHtml::_('jquery.framework');
		JHtml::_('jquery.ui');
	$document->addScript('https://www.google.com/jsapi');
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/ajax.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/gm_map.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/jquery.ui.accordion.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/markerclusterer_min.js' );
 	
	require_once 'helpers/gmap_mobile_detect.php';
    $detect = new gmap_Mobile_Detect;
    $deviceType = ($detect->isMobile() ? ($detect->isTablet() ?
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_tablet.css')
		: 
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_mobile.css'))
		:
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_pc.css')); 
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/jquery.fancybox-1.3.4.css');	
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/gm_map.css');	
		$js = "google.load('visualization', '1', {packages: ['table','corechart']});
				var URIBase = '".JURI::root()."';";
		$document->addScriptDeclaration( $js );	

				$replacement =  '';
				$map = '/{gm'.$id.'}/';
				$row->text = preg_replace( $map, $replacement, $row->text );

	
	}
	
	//Secure View Karte identifizieren		
	$regex1 = '/{secureviewgm.+?}/';
	preg_match_all ($regex1, $row->text, $karten,PREG_SET_ORDER);
	if (count($karten) > 0){
		for ($i=0, $n=count($karten); $i < $n; $i++){
			$karte = trim($karten[$i][0], "\{secureviewgm"); 
			$id = trim($karte, "\}");
			$replacement =  '<iframe name="Google Map" src="index.php?option=com_gmap&amp;view=gm_modal&amp;tmpl=component&amp;layout=default&amp;map='.$id.'" style="width:100%; height:100%; border:none"></iframe>';
			$map = '/{secureviewgm'.$id.'}/';
			$row->text = preg_replace( $map, $replacement, $row->text );
		};
	
	}
	
	//Kartenlinks identifizieren
	$regex2 = '/com_gmap&amp;view=gm_modal/';
preg_match_all ($regex2, $row->text, $karten,PREG_SET_ORDER);
	if (count($karten) > 0){
		JHTML::_('behavior.core', true);
		JHtml::_('jquery.framework');
		JHtml::_('jquery.ui');
		$js3 = "
			jQuery(document).ready(function() {
			jQuery('a[rel=example_group]').fancybox({
				'width'				: '90%',
				'height'			: '90%',
				'autoScale'			: true,
				'transitionIn'		: 'elastic',
				'transitionOut'		: 'elastic',
				'type'				: 'iframe'
			});});
			";
		$document->addScriptDeclaration( $js3 );
		$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/jquery.ui.accordion.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/jquery.fancybox-1.3.4.pack.js' );
	$document->addScript( JURI::root(true).'/plugins/content/plg_content_gmap/assets/js/markerclusterer_min.js' );
	require_once 'helpers/gmap_mobile_detect.php';
    $detect = new gmap_Mobile_Detect;
    $deviceType = ($detect->isMobile() ? ($detect->isTablet() ?
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_tablet.css')
		: 
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_mobile.css'))
		:
		$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/map_button_pc.css')); 
	$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/jquery.fancybox-1.3.4.css');
	$document->addStyleSheet('plugins/content/plg_content_gmap/assets/css/gm_map.css');		

	}
}//function
}