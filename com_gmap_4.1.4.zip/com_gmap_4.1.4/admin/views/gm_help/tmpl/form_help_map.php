<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

 
//-- No direct access
defined('_JEXEC') or die('Restricted access');
$language = JFactory::getLanguage();
$language->load('com_gmap_help');
 echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_HELP_MAP' ); 
 
 ?>