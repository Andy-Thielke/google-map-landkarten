<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
?>
<script type="text/javascript">
google.maps.visualRefresh = false;
document.addEvent('domready', function() {
            var tabPane = new TabPane('tab');
			var subtabPane = new TabPane('subtab');
			var subtabPanemarker = new TabPane('subtabmarker');
			var subtabPanerectangle = new TabPane('subtabrectangle');
			var subtabPanecircle = new TabPane('subtabcircle');
			var subtabPaneline = new TabPane('subtabline');
			var subtabPanepolygon = new TabPane('subtabpolygon');
			var subtabPanetext = new TabPane('subtabtext');

        });
window.addEvent('load', function() {initialize(); });		
</script>

<form action="index.php" method="post" name="adminForm" id="adminForm">	
<table  border="0">
  <tr>
    <td nowrap="nowrap"width="165" class="control-label"><?php echo $this->form->getLabel('showelement'); ?></td>
    <td class="control"><?php echo $this->form->getInput('showelement'); ?></td>
    <td width="100" >
    <a class="btn btn-small" onclick="main.SaveAllElements()" href="#">
	<span class="icon-save"></span>
	<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_MARKER_BUTTON_SAVE' ); ?>
    </a>
    </td>
    <td><div id="savebar"><div id="progress-label2" class="progress-label2"></div></div></td>
    </tr>
  <tr>
    <td colspan="2" class="cell-1">
      
      <div id="map_container" class="resizable" style="width:<?php echo $this->config->conf_map_breite; ?>px; height:<?php echo $this->config->conf_map_hoehe; ?>px; position: relative;">
        <div id="loadbar"><div class="progress-label">Loading...</div></div>
        <div id="map" style="width:100%; height:100%"></div>
        </div>
      <div id="map_elevation"></div>   </td>
    <td colspan="2"  class="cell-1">
      <div id="tab">
      <ul class="tabs">
        <li id="tab1" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_MAP_SETUP' ); ?> </li>
        <li onClick="showmarker()" id="tab2" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_MARKER' ); ?> </li>
        <li onClick="showrectangle()" id="tab3" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_RECANGLE' ); ?> </li>
        <li onClick="showcircle()" id="tab4" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_CIRCLE' ); ?> </li>
        <li onClick="showline()" id="tab5" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_LINE' ); ?> </li>
        <li onClick="showpolygon()" id="tab6" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_POLYGON' ); ?> </li>
        <li onClick="showtext()" id="tab7" class="tab"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_TAB_HTMLBOX' ); ?> </li>
        </ul>
      <div id="tabcontent1" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <?php echo $this->loadTemplate('map');?>    
          </div> 
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      
      <div id="tabcontent2" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('marker');
?>
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      <div id="tabcontent3" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('rectangle');
?>
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      <div id="tabcontent4" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('circle');
?>
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      <div id="tabcontent5" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('line');
?>
          
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      <div id="tabcontent6" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('polygon');
?>
          
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      <div id="tabcontent7" class="tabcontent">
        <div class="t">
          <div class="t">
            <div class="t"></div>
            </div>
          </div>
        <div class="m">
          <div class="clr"></div>
          <?php
echo $this->loadTemplate('text');
?>
          
          </div>	
        <div class="b">
          <div class="b">
            <div class="b"></div>
            </div>
          </div> 
        </div>
      
      </td>
  </tr>
</table>
	<?php echo $this->form->getInput('map_width'); ?>
    <?php echo $this->form->getInput('map_height'); ?>
	<input type="hidden" id="map_lat" value="<?php echo $this->item->map_center_lat; ?>" />
	<input type="hidden" id="default_lat" value="<?php echo $this->config->conf_center_lat; ?>" />
	<input type="hidden" id="default_lng" value="<?php echo $this->config->conf_center_lng; ?> " />
	<input type="hidden" id="default_zoom" value="<?php echo $this->config->conf_start_zoom; ?> " />
    <input type="hidden" id="map_id" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="option" value="com_gmap" />
	<input type="hidden" name="task" value="save_map" />
   <input type="hidden" name="view" value="gm_editor" /> 
	<input type="hidden" name="controller" value="gm_editor" />

</form>

