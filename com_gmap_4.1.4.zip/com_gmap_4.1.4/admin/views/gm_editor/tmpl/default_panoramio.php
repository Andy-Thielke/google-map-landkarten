<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/
 
//-- No direct access
defined('_JEXEC') or die('Restricted access');
?>
  <table>
    <tr class="gm_row1">
      <td class="control-label"><?php echo $this->form->getLabel('map_panoramio_layer'); ?></td>
      <td class="controls"><?php echo $this->form->getInput('map_panoramio_layer'); ?></td>
     </td>
      <td>&nbsp;</td>
    </tr>
    <tr class="gm_row0">
      <td class="control-label"><?php echo $this->form->getLabel('panoramio_tag'); ?></td>
      <td class="controls"><?php echo $this->form->getInput('panoramio_tag'); ?></td>
      <td rowspan="2"><a href="javascript:void(0)" onclick="map_panoramio.refresh_view()" ><img src="components/com_gmap/assets/images/refresh.png" width="16" height="16" title="<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_MAP_BUTTON_REFRESH_PANORAMIO' ); ?>" class="assume" /></a></td>
    </tr>
     <tr class="gm_row1">
      <td class="control-label"><?php echo $this->form->getLabel('panoramio_userid'); ?></td>
      <td class="controls"><?php echo $this->form->getInput('panoramio_userid'); ?></td>
    </tr>
    </table>
