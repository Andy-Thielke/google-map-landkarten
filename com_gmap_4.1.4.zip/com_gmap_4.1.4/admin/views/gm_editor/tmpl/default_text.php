<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/
 
//-- No direct access
defined('_JEXEC') or die('Restricted access');
?>
<div id="tab-7">
<div class="subhead">
<div id="toolbar" class="btn-toolbar">
<div id="toolbar-save" class="btn-wrapper">
	<a class="btn btn-small" onclick="textnew()" href="#">
	<span class="icon-plus-2"></span>
	<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_MARKER_BUTTON_NEW' ); ?>
    </a>
    <a class="btn btn-small" onclick="resettext()" href="#">
	<span class="icon-undo"></span>
	<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_MARKER_BUTTON_RESTORE' ); ?>
    </a>
    <a class="btn btn-small" onclick="selectedtextdelete()" href="#">
	<span class="icon-delete"></span>
	<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_MARKER_BUTTON_DELETE' ); ?>
    </a>
     </div>
<div id="toolbar-help" class="btn-wrapper">    
	<a class="modal-button btn btn-small" href=<?php echo $this->config->help_html_box?>>
    <span class="icon-question-sign"></span>
	<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_BUTTON_HELP' ); ?>
    </a>
</div>
</div>
</div>
	<ul id="htmlbox-tab" class="nav nav-tabs" role="tablist" style="margin-bottom: 5px;">
		<li class="active">
  			<a href="#htmlbox-page-1" role="tab" data-toggle="tab">
			<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_SUBTAB_HTMLBOXEDIT' ); ?></a>
		</li>
		<li>
  			<a onClick="inittexttabelle()" href="#htmlbox-page-2" role="tab" data-toggle="tab">
			<?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_SUBTAB_TABLE_HTMLBOX' ); ?></a>
		</li>
    </ul>

<div class="tab-content">
<div class="tab-pane active" id="htmlbox-page-1">
<div id="page-section"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_HTMLBOX_FIELDSET_POSITION' ); ?></div>
<table border="0">
	<tr class="gm_row1">
      <td class="control-label"><?php echo $this->form->getLabel('text_lat'); ?></td>
      <td class="controls"><?php echo $this->form->getInput('text_lat'); ?></td>
    </tr>
    <tr class="gm_row1">
      <td class="control-label"><?php echo $this->form->getLabel('text_lng'); ?></td>
      <td class="controls"><?php echo $this->form->getInput('text_lng'); ?></td>
    </tr>
 </table>
<div id="page-section"><?php echo JText::_( 'COM_GMAP_VIEW_GM_MAP_EDITOR_HTMLBOX_FIELDSET_EDITOR' ); ?></div>
<?php echo $this->form->getInput('text_box_beschreibung'); ?>
        </div>
<div class="tab-pane" id="htmlbox-page-2">
  <div class="subtabelle" id="page_texttabelle"></div>
</div>
<input type="hidden" id ="activtext" name="activtext" value="" />		
 
</div>	
</div>
