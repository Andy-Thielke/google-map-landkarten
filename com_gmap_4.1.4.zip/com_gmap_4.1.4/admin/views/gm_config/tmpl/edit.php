<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

?>

<script language="javascript" type="text/javascript">
window.addEvent('load', function() {initialize(); });
var map;
var backup;

function initialize() {
	var start = new google.maps.LatLng(<?php echo $this->item->conf_center_lat?>,<?php echo $this->item->conf_center_lng?>);
 	var myOptions = {
      zoom: <?php echo $this->item->conf_start_zoom;?>,
      center: start,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map($('map'), myOptions);
    kartenwerte();
	}
	
	function kartenwerte() {
	var mapcenter =  map.getCenter();
	$('jform_conf_center_lat').value =mapcenter.lat();
	$('jform_conf_center_lng').value =mapcenter.lng();	
	$('jform_conf_start_zoom').value = map.getZoom();
getBackupMsg();	
	}
function create_backup() {
	var msg;
	var siteurl= "index.php?option=com_gmap&task=gm_config.create_backup";
  	jQuery.ajax({
			url		: siteurl,
			async: false,
			type: "POST",
			error:function(){
                    msg ='<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_NEW_FAILURE_MSG' ); ?>';
					return msg;
                },
			 success: function() {
					msg ='<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_NEW_MSG' ); ?>';
					$('msg_backup_2').innerHTML = '';
					getBackupMsg ();
					return msg;
           },
        });
	alert (msg);
}
function restore_backup() {
 if (backup == '1'){
	var msg;
	var siteurl= "index.php?option=com_gmap&view=gm_config&tmpl=component&layout=form_restore_backup&format=raw&backup_import=<?php echo $this->backup_info['backup_import'];?>";
  	jQuery.ajax({
			url		: siteurl,
			async: false,
			type: "GET",
			dataType:"json",
			error:function(){
                    msg ='<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_RESTORE_FAILURE_MSG' ); ?>';
					return msg;
                },
			 success: function(response) {
				 	var res = response;
					msg ='<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_RESTORE_MSG' ); ?>';
					$('msg_backup_2').innerHTML =res;
					return msg;
           },
        });
	alert (msg);
 }else{
	alert ('<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BACKUP_NOT_PRESENT'); ?>'); 
 };
getBackupMsg ();
}

function getBackupMsg () {
		var siteurl="index.php?option=com_gmap&view=gm_config&tmpl=component&layout=form_backup&format=raw";
		jQuery.ajax({
			url		: siteurl,
			async: false,
			type: "GET",
			dataType:"json",
			error:function(){
				alert('<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_LOAD_BACKUP_INFO_FAILURE_MSG' ); ?>');
                },
			 success: function(response) {
				var res = response;
				if (typeof res.backup_info === 'undefined'){
					$('msg_backup_1').innerHTML ='<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BACKUP_NOT_PRESENT' ); ?>';
					backup = '0';
				}else{
					$('msg_backup_1').innerHTML = res.backup_info;
					backup = '1';
				}
           },
        });
}
	 
</script>
<form action="<?php echo JRoute::_('index.php?option=com_gmap&layout=edit&id=1'); ?>" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'config')); ?>
<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'config', JText::_('COM_GMAP_VIEW_CONFIG_TAB_LABEL_CONFIG'), true); ?>

	<div class="row-fluid">
		<div class="span12 form-horizontal">
	<fieldset class="adminform">
    <legend><?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_TITLE_CONFIG' ); ?></legend>
    <table style="float: left;"  border="0">
  <tr>
    <td class="control-label"><?php echo $this->form->getLabel('conf_map_breite'); ?></td>
    <td class="controls"><?php echo $this->form->getInput('conf_map_breite'); ?></td>
    </tr>
  <tr>
    <td class="control-label"><?php echo $this->form->getLabel('conf_map_hoehe'); ?></td>
    <td class="controls"><?php echo $this->form->getInput('conf_map_hoehe'); ?></td>
    </tr>
  <tr>
    <td class="control-label"><?php echo $this->form->getLabel('conf_center_lat'); ?></td>
    <td class="controls"><?php echo $this->form->getInput('conf_center_lat'); ?></td>
    </tr>
  <tr>
    <td class="control-label"><?php echo $this->form->getLabel('conf_center_lng'); ?></td>
    <td class="controls"><?php echo $this->form->getInput('conf_center_lng'); ?></td>
    </tr>
  <tr>
    <td class="control-label"><?php echo $this->form->getLabel('conf_start_zoom'); ?></td>
    <td class="controls"><?php echo $this->form->getInput('conf_start_zoom'); ?></td>
    </tr>
  <tr>
    <td class="control-label"></td>
    <td class="controls"><input type="button" value="<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_LABEL_MAP_LAT_LNG' ); ?>" onClick="kartenwerte()"></td>
  </tr>
  </table>
<div id="map" style="width:400px; height:400px;"></div>
	</fieldset>
		</div>
	</div>
	<div>
		<input type="hidden" name="task" value="gm_config.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
<?php echo JHtml::_('bootstrap.endTab'); ?>
<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'misc', JText::_('COM_GMAP_VIEW_CONFIG_TAB_LABEL_BACKUP')); ?>
<table  border="0">
  <tr>
    <td colspan="2"><div id="msg_backup_1"></div>
    </td>
  </tr>
  <tr>
    <td colspan="2"><div id="msg_backup_2"></div>
    </td>
  </tr>
  <tr>
    <td>
<?php
	if ($this->backup_info['backup_import'] == '1'){
		echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BUTTON_DATA_IMPORT_INFO' );
	};
?>    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input name="" type="button" onClick="create_backup();" value="<?php echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BUTTON_NEW' ); ?>">
    
    <input name="" type="button" onClick="restore_backup();" value="<?php 
	if ($this->backup_info['backup_import'] == '1'){
		echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BUTTON_DATA_IMPORT' );
	}else {
		echo JText::_( 'COM_GMAP_VIEW_CONFIG_BACKUP_BUTTON_RESTORE' ); 
	};
		?>"></td>
    <td></td>
  </tr>
</table>
<?php echo JHtml::_('bootstrap.endTab'); ?>
  
</form>