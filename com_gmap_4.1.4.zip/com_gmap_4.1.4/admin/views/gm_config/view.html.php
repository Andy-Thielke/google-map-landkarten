<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * Gmaps View
 */
class GmapViewgm_config extends JViewLegacy
{

	public function display($tpl = null)
	{
		$form = $this->get('Form');
		$item = $this->get('Item');
		$script = $this->get('Script');
		$backup_info = $this->get('BackupInfo');
		// Check for errors.
		if (count($errors = $this->get('Errors'))){
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		};
		// Assign the variables
		$this->form = $form;
		$this->item = $item;
		$this->script = $script;
		$this->backup_info = $backup_info;
		// Set the toolbar
		$this->addToolBar();

		// Display the template
		parent::display($tpl);

		// Set the document
		$this->setDocument();
	}

	protected function addToolBar()
	{
		JFactory::getApplication()->input->set('hidemainmenu', true);
		$user = JFactory::getUser();
		$userId	= $user->id;
		$canDo = GmapHelper::getActions($this->item->id);
		// Built the actions for existing records.
			if ($canDo->get('core.edit')){
				// We can save the record
				JToolBarHelper::save('gm_config.update_config', 'JTOOLBAR_SAVE');
			};
		if($canDo->get('core.admin')){
			JToolBarHelper::divider();
			JToolBarHelper::preferences('com_gmap');
		};
			JToolBarHelper::cancel('gm_config.cancel', 'JTOOLBAR_CLOSE');
	}
	protected function setDocument() 
	{
		JToolBarHelper::title(JText::_('COM_GMAP_VIEW_CONFIG_TITLE_CONFIG'), 'gm_config');
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('COM_GMAP_VIEW_CONFIG_TITLE_CONFIG'));
		$document->addScript('https://maps.google.com/maps/api/js?&sensor=false');

	}
}
?>