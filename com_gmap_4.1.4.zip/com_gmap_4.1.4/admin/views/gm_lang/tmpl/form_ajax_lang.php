<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

//-- No direct access
defined('_JEXEC') or die('Restricted access');
$a=1;

	
$response = &$this->lang;

$html = "
<div class='setup_button' title='".$response->lang_button_title."' onclick='togglemapsetupview();' id='setup-button'>
</div>
<dl class='accordion' id='setup_button_box'>
<dt id='accordion_toggler_1' class='accordion_toggler_1'>".$response->lang_slider_map_view."</dt>
<dd class='accordion_content_1' id='button_wrapper_1'>
<ul id='button_list_1'>
<li class='list_item_off' id='map_view_item_roadmap' onclick='setmaplayer.maptyp(\"roadmap\")'><span class='list_item_text'>
".$response->lang_map_view_roadmap."</span></li>
<li class='list_item_off' id='map_view_item_terrain' onclick='setmaplayer.maptyp(\"terrain\")'><span class='list_item_text'>
".$response->lang_map_view_terrain."</span></li>
<li class='list_item_off' id='map_view_item_satellite' onclick='setmaplayer.maptyp(\"satellite\")'><span class='list_item_text'>".$response->lang_map_view_satellite."</span></li>
<li class='list_item_off' id='map_view_item_hybrid' onclick='setmaplayer.maptyp(\"hybrid\")'><span class='list_item_text'>
".$response->lang_map_view_hybrid."</span></li>
</ul>
</dd>
<dt id='accordion_toggler_2' class='accordion_toggler_1'>".$response->lang_slider_layer."</dt>
<dd class='accordion_content_1'>
<ul id='button_list_2'>
<li class='list_item_off' id='map_layer_bike' onclick='setmaplayer.map_bike_layer()'><span class='list_item_text'>
".$response->lang_layer_bike."</span></li>
<li class='list_item_off' id='map_layer_traffic' onclick='setmaplayer.map_traffic_layer()'><span class='list_item_text'>
".$response->lang_layer_traffic."</span></li>
<li class='list_item_off' id='map_layer_transit' onclick='setmaplayer.map_transit_layer()'><span class='list_item_text'>
".$response->lang_layer_transit."</span></li>
<li class='list_item_off' id='map_layer_weather' onclick='setmaplayer.map_weather_layer()'><span class='list_item_text'>
".$response->lang_layer_weather."</span></li>
<li class='list_item_off' id='map_layer_streetview' onclick='setmaplayer.map_streetview_layer()'><span class='list_item_text'>".$response->lang_layer_streetview."</span></li>
</ul>
</dd>
<dt id='accordion_toggler_3' class='accordion_toggler_1'>".$response->lang_slider_panoramio."</dt>
<dd class='accordion_content_1'>
<ul id='button_list_3'>
<li class='list_item_off' id='map_layer_panoramio' onclick='setmaplayer.map_panoramio_layer()'><span class='list_item_text'>
".$response->lang_panoramio_panoramio."</span></li>
</ul>
</dd>
</dl>";
$response->map_button_html = $html;


    require_once( JPATH_COMPONENT.DS.'helpers'.DS.'json.php' );
   $json = new Services_JSON();
   echo $json->encode( $response );