<?php
/*------------------------------------------------------------------------
# gmap - google map landkarten Component
# ------------------------------------------------------------------------
# author    Andy Thielke
# copyright Copyright (C) 2014. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.joomla.de.com
-------------------------------------------------------------------------*/

// no direct access

defined('_JEXEC') or die('Restricted access');
 
class com_gmapInstallerScript
{	
	private $release = '4.1.4';
	private $msg = '';

	function install($parent) 
	{  
		require_once(dirname(__FILE__) .'/admin/updates/views/install_4.1.4.html');
		echo '<p> Installation der Google Map Landkarten Version ' .JText::_($this->release) .' erfolgreich abgeschlossen!</p>';
	}

	function uninstall($parent) 
	{
		 $db = JFactory::getDbo();
    		$query = "DELETE FROM #__extensions WHERE element= 'plg_content_gmap';"; 
		  $db->setQuery($query);
		  if ($db->Query()){
			  JFolder::delete(JPATH_ROOT.'/plugins/content/plg_content_gmap');
				$this->msg .= '<p>Plugin Content für Google Map Landkarten wurde Deinstalliert!</p>';
			  }
      		$query = "DELETE FROM #__extensions WHERE element= 'plg_editors_xtd_gmap';"; 
		 	$db->setQuery($query);
		  if ($db->Query()){
			  JFolder::delete(JPATH_ROOT.'/plugins/editors-xtd/plg_editors_xtd_gmap');
				$this->msg .= '<p>Plugin Editor Button für Google Map Landkarten wurde Deinstalliert!</p>';
			  }
      		$query = "DELETE FROM #__extensions WHERE element= 'plg_search_gmap';"; 
		  	$db->setQuery($query);
		  if ($db->Query()){
			  JFolder::delete(JPATH_ROOT.'/plugins/search/plg_search_gmap');
				$this->msg .= '<p>Plugin Search für Google Map Landkarten wurde Deinstalliert!</p>';
			  }
		echo $this->msg;	
	}

	function update($parent) 
	{
		$this->release=$parent->get("manifest")->version;
		$oldRelease = $this->getParam('version');
		$mainframe = JFactory::getApplication();
		if (version_compare($this->release, $oldRelease, '>')) {
			if ($oldRelease == '4.1') {
				$this->update_to_4_1_4();
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.1.1_to_4.1.4.html');
			}else if ($oldRelease == '4.1.1') {
				$this->update_to_4_1_4();
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.1.1_to_4.1.4.html');
			}else if ($oldRelease == '4.1.2') {
				$this->update_to_4_1_4();
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.1.1_to_4.1.4.html');
			}else if ($oldRelease == '4.1.2.1') {
				$this->update_to_4_1_4();
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.1.1_to_4.1.4.html');
			}else if ($oldRelease == '4.1.3') {
				$this->update_to_4_1_4();
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.1.3_to_4.1.4.html');
			}else{
				$this->update_to_4_1();//Update zu 4.1.4
				require_once(JPATH_ADMINISTRATOR.'/components/com_gmap/updates/views/update_from_4.0_to_4.1.4.html');
			}
		echo $this->msg;
		echo '<p> Update auf Google Map Landkarten Version ' .JText::_($this->release) .' erfolgreich abgeschlossen!</p>';
		
	}
	}

	function preflight( $type, $parent ) {
		$jversion = new JVersion();
		$this->release=$parent->get("manifest")->version;
		$this->minimum_joomla_release = $parent->get( "manifest" )->attributes()->version;
		if( version_compare( $jversion->getShortVersion(), $this->minimum_joomla_release, 'lt' ) ) {
                Jerror::raiseWarning(null, 'Cannot install Google Map Landkarten in a Joomla release prior to '.$this->minimum_joomla_release.'</br>Für diese Komponente ist min. Joomla! '.$this->minimum_joomla_release.' erforderlich!');
                return false;
        }
		$oldRelease = $this->getParam('version');
		$mainframe = JFactory::getApplication();
			if ($oldRelease == '3.3.3') {
				Jerror::raiseWarning(null, 'Bitte erst Version 3.3.3 deinstallieren!');
				return false;
			}
	} 

	function postflight($type, $parent) 
	{	
		if ( $type == 'install' ){
		  JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/com_gmap',JPATH_ROOT.'/images/stories/com_gmap','',true);
      JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_content_gmap',JPATH_ROOT.'/plugins/content/plg_content_gmap','',true);
      JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_editors_xtd_gmap',JPATH_ROOT.'/plugins/editors-xtd/plg_editors_xtd_gmap','',true);
      JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_search_gmap',JPATH_ROOT.'/plugins/search/plg_search_gmap','',true);
		  $db = JFactory::getDbo();
      $mcache1 = '{"legacy":false,"name":"Content Plugin for Google Map Landkarten","type":"plugin","creationDate":"Feb-2014","author":"Andy Thielke","copyright":"Copyright (C)2014 Andy Thielke","authorEmail":"kontakt@joomla.de.com","authorUrl":"http:\/\/www.joomla.de.com","version":"4.0","description":"Content Plugin for Google Map Landkarten.","group":""}' ;
      $query1 = "INSERT INTO #__extensions (extension_id, name, type, element, folder, client_id, enabled, access, protected, manifest_cache, params, custom_data, system_data, checked_out, checked_out_time, ordering, state) VALUES ('', 'Content Google Map Landkarten', 'plugin', 'plg_content_gmap', 'content', '0', '1', '1', '0', '$mcache1', '', '', '', '0', '0000-00-00 00:00:00', '0', '0');"; 
		  $db->setQuery($query1);
		  if ($db->Query()){
			$this->msg .= '<p>Plugin Content für Google Map Landkarten wurde installiert und aktiviert!</p>';
			  }
      $mcache2 = '{"legacy":false,"name":"Editor Button Plugin for Google Map Landkarten","type":"plugin","creationDate":"Feb-2014","author":"Andy Thielke","copyright":"Copyright (C)2014 Andy Thielke","authorEmail":"kontakt@joomla.de.com","authorUrl":"http:\/\/www.joomla.de.com","version":"4.0","description":"Editor Button Plugin for Google Map Landkarten.","group":""}' ;
		  $query2 = "INSERT INTO #__extensions (extension_id, name, type, element, folder, client_id, enabled, access, protected, manifest_cache, params, custom_data, system_data, checked_out, checked_out_time, ordering, state) VALUES ('', 'Editor Button Google Map Landkarten', 'plugin', 'plg_editors_xtd_gmap', 'editors-xtd', '0', '1', '1', '0', '$mcache2', '', '', '', '0', '0000-00-00 00:00:00', '0', '0');"; 
		  $db->setQuery($query2);
		  if ($db->Query()){
			$this->msg .= '<p>Plugin Editor Button für Google Map Landkarten wurde installiert und aktiviert!</p>';
			  }
      $mcache3 = '{"legacy":false,"name":"Search Plugin for Google Map Landkarten","type":"plugin","creationDate":"Feb-2014","author":"Andy Thielke","copyright":"Copyright (C)2014 Andy Thielke","authorEmail":"kontakt@joomla.de.com","authorUrl":"http:\/\/www.joomla.de.com","version":"4.0","description":"Search Plugin for Google Map Landkarten.","group":""}' ;
		  $query3 = "INSERT INTO #__extensions (extension_id, name, type, element, folder, client_id, enabled, access, protected, manifest_cache, params, custom_data, system_data, checked_out, checked_out_time, ordering, state) VALUES ('', 'Search Google Map Landkarten', 'plugin', 'plg_search_gmap', 'search', '0', '0', '1', '0', '$mcache3', '', '', '', '0', '0000-00-00 00:00:00', '0', '0');"; 
		  $db->setQuery($query3);
		  if ($db->Query()){
			$this->msg .= '<p>Optionales Plugin Search für Google Map Landkarten wurde installiert und deaktiviert! F&uuml;r eine Integration in die Site Suche bitte aktivieren</p>';
			  }
		echo $this->msg;
		}
		
}
		function getParam( $name ) {
		$db = JFactory::getDbo();
		$db->setQuery('SELECT manifest_cache FROM #__extensions WHERE element = '.$db->quote('com_gmap'));
		$manifest = json_decode( $db->loadResult(), true );
		return $manifest[ $name ];
		}
		function update_to_4_1(){
			$db = JFactory::getDbo();
			///////update the content plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_content_gmap',JPATH_ROOT.'/plugins/content/plg_content_gmap','',true)){
			$this->msg .= '<p>Das Content Plugin wurde aktualisiert !</p>';  
		  	}
			///////update the content plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_editors_xtd_gmap',JPATH_ROOT.'/plugins/editors-xtd/plg_editors_xtd_gmap','',true)){
				$this->msg .= '<p>Das Editor Button Plugin wurde aktualisiert !</p>';  
		  	}
			///////update the search plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_search_gmap',JPATH_ROOT.'/plugins/search/plg_search_gmap','',true)){
				$this->msg .= '<p>Das Suchen Plugin wurde aktualisiert !</p>';  
		  	}
			///////////Create polygon table/////////
			$query = "CREATE TABLE #__gm_polygon (
					  id int(11) NOT NULL AUTO_INCREMENT,
					  id_map int(10) NOT NULL,
					  polygon_titel varchar(100) NOT NULL,
					  polygon_color_line varchar(10) NOT NULL,
					  polygon_width_line varchar(2) NOT NULL,
					  polygon_transparent_line varchar(5) NOT NULL,
					  polygon_color_fill varchar(10) NOT NULL,
					  polygon_transparent_fill varchar(5) NOT NULL,
					  polygon_path text NOT NULL,
					  polygon_parameter text NOT NULL,
					  polygon_beschreibung text NOT NULL,
					    PRIMARY KEY (id),
						UNIQUE KEY id (id)
					) ";
			$db->setQuery($query);
			if ($db->Query()){
				$this->msg .= '<p>Neue Polygon Tabelle wurde erstellt!</p>';	
			}
			////////erweitern der circle Tabelle////////////
			$query = "ALTER TABLE #__gm_circle ADD (circle_beschreibung text NOT NULL) "; 
			$db->setQuery($query);
			if ($db->Query()){
				$this->msg .= '<p>Die Circle Tabelle wurde erweitert!</p>';	
			}
			////////erweitern der circle Tabelle////////////
			$query = "ALTER TABLE #__gm_rectangle ADD (rectangle_beschreibung text NOT NULL) "; 
			$db->setQuery($query);
			if ($db->Query()){
				$this->msg .= '<p>Die Rectangle Tabelle wurde erweitert!</p>';	
			}
			////////erweitern der circle Tabelle////////////
			$query = "ALTER TABLE #__gm_line ADD (line_beschreibung text NOT NULL) "; 
			$db->setQuery($query);
			if ($db->Query()){
				$this->msg .= '<p>Die Line Tabelle wurde erweitert!</p>';	
			}
			////////update rectangle Data////////
			$query ="SELECT * FROM #__gm_rectangle ORDER BY id ASC";
			$db->setQuery($query);
			if ($items = $db->loadObjectList()){
				for ($i=0, $n=count($items); $i < $n; $i++){
					$item = $items[$i];
					$newpos1=$item->rectangle_position2_lat;
					$newpos2=$item->rectangle_position2_lng;
					$newpos3=$item->rectangle_position1_lat;
					$newpos4=$item->rectangle_position1_lng;
					$rid = $item->id;
				$query = "UPDATE #__gm_rectangle SET rectangle_position1_lat='$newpos1',rectangle_position1_lng='$newpos2',rectangle_position2_lat='$newpos3',rectangle_position2_lng='$newpos4' WHERE id='$rid'"; 
				$db->setQuery($query);
				$db->Query();
				}
			}
			$this->msg .= '<p>'.count($items).' Rectangle Daten wurden aktualisiert</p>';
		}
		function update_to_4_1_4(){
			$db = JFactory::getDbo();
			///////update the content plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_content_gmap',JPATH_ROOT.'/plugins/content/plg_content_gmap','',true)){
			$this->msg .= '<p>Das Content Plugin wurde aktualisiert !</p>';  
		  	}
			///////update the content plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_editors_xtd_gmap',JPATH_ROOT.'/plugins/editors-xtd/plg_editors_xtd_gmap','',true)){
				$this->msg .= '<p>Das Editor Button Plugin wurde aktualisiert !</p>';  
		  	}
			///////update the search plugin///////////////
			if (JFolder::copy(JPATH_ADMINISTRATOR.'/components/com_gmap/plugins/plg_search_gmap',JPATH_ROOT.'/plugins/search/plg_search_gmap','',true)){
				$this->msg .= '<p>Das Suchen Plugin wurde aktualisiert !</p>';  
		  	}
		}
}

